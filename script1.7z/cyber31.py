import requests,time
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...

while True:

 headers = {
    'Host': 'api.cyberfin.xyz',
    # 'Content-Length': '340',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Accept': 'application/json',
    'Secret-Key': 'cyberfinance',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://g.cyberfin.xyz',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://g.cyberfin.xyz/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}


 json_data = {
    'initData': 'query_id=AAFLaE88AwAAAEtoTzy-_hRa&user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22cryptoooboy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1719634432&hash=95df5a1d51a545afb142deb72e33cd2bbe62d515630091e7d2db792452e04413',
}

 response = requests.post('https://api.cyberfin.xyz/api/v1/game/initdata', headers=headers, json=json_data, verify=False)
 accesstoken=response.json()['message']['accessToken']
 headers1 = {
    'Host': 'api.cyberfin.xyz',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Accept': 'application/json',
    'Secret-Key': 'cyberfinance',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {accesstoken}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.52 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://g.cyberfin.xyz',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://g.cyberfin.xyz/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 response1 = requests.get('https://api.cyberfin.xyz/api/v1/mining/claim', headers=headers1, verify=False)
 print(response1.text)
 print("sleeping 2 hr")
 time.sleep(7200)