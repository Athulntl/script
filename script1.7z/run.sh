#!/bin/bash

# Start a new tmux session named "python_sessions"
tmux new-session -d -s python_sessions

# Array of Python program names
programs=(
    "celia.py"
    "cex.py"
    "hex.py"
    "dot77.py"
    "dot79.py"
    "dot99.py"
    "dot31.py"
    "cyber.py"
    "pixel.py"
    "hamster.py"
    "yescoin.py"
    "seed.py"
    "empire.py"
    "hex.py"
    "gamee.py"
    "time.py"
    "beer.py"
    "chick.py"
    "arix.py"
    "bay.py"
    "tom.py"
    "hot.py"
    "pocket.py"
    "richdesk.py"
    "ruby.py"
    "slap.py"
    "slapboost.py"
    "tap1.py"
    "toon.py"
    "arena.py"
    "dragon.py"
    "kibble.py"
    "diamore.py"   
    "loca.py"
    "tom.py"
    "ruby.py"  
    "nomi.py"
    "lfg.py"
    "cryptorank.py"
    "nomi.py"
)






  

# Loop through the programs array and create a new window for each program
for program in "${programs[@]}"; do
    # Create a new window
    tmux new-window -t python_sessions -n "$program"
    
    # Send the Python program to the new window
    tmux send-keys -t python_sessions: "python $program" C-m
done

# Attach to the session to view the windows
tmux attach-session -t python_sessions
7







