import requests
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...

while True:
 

 headers = {
    'Host': 'ff.notgemz.gemz.fun',
    # 'Content-Length': '32',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.52 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://ff.notgemz.gemz.fun',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://ff.notgemz.gemz.fun/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = {
    'userId': '1086441183',
    'taps': 1000,
}

 response = requests.post('https://ff.notgemz.gemz.fun/add-points', headers=headers, json=json_data, verify=False)
 print('77',response.text)

# Note: json_data will not be serialized by requests
# exactly as it was in the original request.
#data = '{"userId":"1086441183","taps":1}'
#response = requests.post('https://notgemz.game.prod.pnk.one/add-points', headers=headers, data=data, verify=False)







