import threading
import requests
import time
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from datetime import datetime

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

def send_request1():
    headers = {
        'Host': 'api.chickcoop.io',
        'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
        'Content-Type': 'application/octet-stream',
        'Sec-Ch-Ua-Mobile': '?1',
        'Authorization': 'id=1086441183&first_name=Athul&last_name=G&username=Aaathulll&auth_date=1718997172&hash=e86584a658041fa081ba4837098a03fb5b32482a817271a30614eb71e9e92e58',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
        'Sec-Ch-Ua-Platform': '"Android"',
        'Accept': '*/*',
        'Origin': 'https://game.chickcoop.io',
        'X-Requested-With': 'org.telegram.messenger',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://game.chickcoop.io/',
        'Accept-Language': 'en,en-US;q=0.9',
        'Priority': 'u=1, i',
    }

    while True:
        try:
            response = requests.post('https://api.chickcoop.io/gift/claim', headers=headers, verify=False)
            # Log timestamp and response details
            print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}]")
            print("77 Error (request1):", response.json()['error'])
            print("77 Response (request1):", response.text)
        except Exception as e:
            print(f"An error occurred (request1): {e}")
        time.sleep(600)  # Wait for 600 seconds before sending the next request

def send_request2():
    headers = {
        'Host': 'api.chickcoop.io',
        'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
        'Content-Type': 'application/octet-stream',
        'Sec-Ch-Ua-Mobile': '?1',
        'Authorization': 'id=1086441183&first_name=Athul&last_name=G&username=Aaathulll&auth_date=1718997172&hash=e86584a658041fa081ba4837098a03fb5b32482a817271a30614eb71e9e92e58',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
        'Sec-Ch-Ua-Platform': '"Android"',
        'Accept': '*/*',
        'Origin': 'https://game.chickcoop.io',
        'X-Requested-With': 'org.telegram.messenger',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://game.chickcoop.io/',
        'Accept-Language': 'en,en-US;q=0.9',
        'Priority': 'u=1, i',
    }

    while True:
        try:
            response = requests.post('https://api.chickcoop.io/hatch/manual', headers=headers, verify=False)
            # Log timestamp and response details
            print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}]")
            print("77 Chickens quantity (request2):", response.json()['data']['chickens']['quantity'])
        except Exception as e:
            print(f"An error occurred (request2): {e}")
        time.sleep(3)  # Wait for 3 seconds before sending the next request

# Create threads for both functions
thread1 = threading.Thread(target=send_request1)
thread2 = threading.Thread(target=send_request2)

# Start the threads
thread1.start()
thread2.start()

# Join the threads to the main thread to keep them running
thread1.join()
thread2.join()
