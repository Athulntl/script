import requests
import time
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

tg = [
    "user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=1926895762564923675&chat_type=private&start_param=1086441183&auth_date=1720012549&hash=7e7773e090d4a3a5743a478972787171fd05130618d289f5aee07708cd6480f0",
    "user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22cryptoooboy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-4137996569969058515&chat_type=private&start_param=1086441183&auth_date=1720012249&hash=d9d68712b0ca87f9974e7c9966f19e9dca48bc2b33b5812f18dca3e1f0843ff5",
    "query_id=AAHfxsFAAAAAAN_GwUCTdXNn&user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1720012067&hash=db5b620077ffc33554145cf8b7ff921f8255b453007e23996f57d1a50e1699b9",
    "user=%7B%22id%22%3A6737423619%2C%22first_name%22%3A%22Swa%22%2C%22last_name%22%3A%22Am%22%2C%22username%22%3A%22imSaraswathy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-7444342360911143688&chat_type=private&start_param=1086441183&auth_date=1720013175&hash=b8155ecdc06a1e15e405117f6658a7689086b450cb8c566a6303c02fad5bd4b4"
]

no = ["99", "31", "77", "79"]

while True:
    error_occurred = False  # Flag to check if any error occurs

    for t, n in zip(tg, no):
        headers = {
            'Host': 'diamore-propd.smart-ui.pro',
            'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json',
            'Sec-Ch-Ua-Mobile': '?1',
            'Authorization': f'Token {t}',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Origin': 'https://diamore-app.vercel.app',
            'X-Requested-With': 'com.iMe.android',
            'Sec-Fetch-Site': 'cross-site',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://diamore-app.vercel.app/',
            'Accept-Language': 'en,en-US;q=0.9',
            'Priority': 'u=1, i',
            'Connection': 'keep-alive',
        }

        json_data = {'tapBonuses': 1000}

        try:
            # Sync clicks
            response = requests.post('https://diamore-propd.smart-ui.pro/user/syncClicks', headers=headers, json=json_data, verify=False)
            response.raise_for_status()  # Raise an error for bad status codes

            # Claim daily reward
            response = requests.post('https://diamore-propd.smart-ui.pro/user/claim-daily', headers=headers, verify=False)
            response.raise_for_status()  # Raise an error for bad status codes

            # Get user info
            response1 = requests.get('https://diamore-propd.smart-ui.pro/user', headers=headers, verify=False)
            response1.raise_for_status()  # Raise an error for bad status codes

            # Print the user info
            print(response1.text)
            print(n, response1.json().get('balance', 'No balance found'))
        
        except requests.exceptions.RequestException as e:
            # Print any error that occurs and set the error flag
            print(f"An error occurred: {e}")
            error_occurred = True

    if not error_occurred:
        print("Sleeping for 4 hours...")
        time.sleep(14400)  # Sleep only if no errors occurred
