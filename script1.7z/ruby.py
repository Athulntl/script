import requests,time

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
no=["77","79","99","31"]
list=[1086441183,6737423619,6796696313,7454287947]
while True:
 for i,n in zip(list,no):

  headers = {
    'Host': 'miniapp.openpad.io',
    # 'Content-Length': '21',
    'Access-Control-Allow-Origin': '*',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json;charset=UTF-8',
    'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Microsoft Edge";v="126", "Microsoft Edge WebView2";v="126"',
    'Sec-Ch-Ua-Mobile': '?0',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Origin': 'https://miniapp.openpad.io',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://miniapp.openpad.io/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Priority': 'u=1, i',
}

  json_data = {
    'userId': i,
} 
  try:
   response = requests.post('https://miniapp.openpad.io/api/farmings/checknews', headers=headers, json=json_data, verify=False)
   response = requests.post('https://miniapp.openpad.io/api/tap-to-earn', headers=headers, json=json_data, verify=False)
   print(n ,response.text)
   response = requests.post('https://miniapp.openpad.io/api/farmings', headers=headers, json=json_data, verify=False)
   print(n, response.text)
  except:
   print("RESTART")
  finally:
   time.sleep(1)   















