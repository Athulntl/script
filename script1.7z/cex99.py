import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import time

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Main loop
while True:
    # Set headers
    headers = {
        'Host': 'cexp.cex.io',
        'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
        'Sec-Ch-Ua-Mobile': '?1',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.52 Mobile Safari/537.36',
        'Sec-Ch-Ua-Platform': '"Android"',
        'Origin': 'https://cexp.cex.io',
        'X-Requested-With': 'org.telegram.messenger',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://cexp.cex.io/',
        'Accept-Language': 'en,en-US;q=0.9',
        'Priority': 'u=1, i',
    }

    # JSON data for claimTap API
    json_data_amount = {
        'devAuthData': 1086441183,
        'authData': 'query_id=AAH5Wh0VAwAAAPlaHRXGcdXL&user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1716348765&hash=136cc91cf3c2d469be1ea9cc85680ee797748ea11e3bfccb7aebbd3053bfcd77',
        'data': {'amount': '10'},
    }

    # Send POST request to claimTap API
    response_claim_tap = requests.post('https://cexp.cex.io/api/claimTap', headers=headers, json=json_data_amount, verify=False)

    # Print the balance or error message
    try:
        print("99",response_claim_tap.json()['data']['balance'])
    except:
        print("99 error",response_claim_tap.text)

    # JSON data for startFarm API
    json_data_start_farm = {
        'devAuthData': 6796696313,
        'authData': 'query_id=AAH5Wh0VAwAAAPlaHRXGcdXL&user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1716348765&hash=136cc91cf3c2d469be1ea9cc85680ee797748ea11e3bfccb7aebbd3053bfcd77',
        'data': {},
    }

    # Send POST request to startFarm API
    response_start_farm = requests.post('https://cexp.cex.io/api/startFarm', headers=headers, json=json_data_start_farm, verify=False)

    # JSON data for claimFarm API
    json_data_tap = {
        'devAuthData': 1086441183,
        'authData': 'query_id=AAH5Wh0VAwAAAPlaHRXGcdXL&user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1716348765&hash=136cc91cf3c2d469be1ea9cc85680ee797748ea11e3bfccb7aebbd3053bfcd77',
        'data': {'taps': 50},
    }

    # Send POST request to claimFarm API
    response_claim_farm = requests.post('https://cexp.cex.io/api/claimFarm', headers=headers, json=json_data_start_farm, verify=False)
    tap=requests.post('https://cexp.cex.io/api/claimTaps', headers=headers, json=json_data_tap, verify=False)
    # Print the response from claimFarm
    print("start farm",response_start_farm.text)
    print("farm claim",response_claim_farm.text)
    print("tap",tap.text)

    # Wait for 60 seconds before the next iteration
    time.sleep(60)
