import requests
import time
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

tg = [
    "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjA4MzQ4MDYsInR5cGUiOiJhY2Nlc3MiLCJpYXQiOjE3MjA3NDg0MDYsImF1ZCI6InRnLmFpLmpvYnMiLCJpc3MiOiJ0Zy5haS5qb2JzIiwic3ViIjoiMTA4NjQ0MTE4MyIsImp0aSI6ImE1YzhrMmExZmx5aTE2N3ZhIn0.nMfeNysNH3HSorgaQgGbyWL1WHjcrALU8UesEFD9hxKzYJX2Gi1WuZy7kpPDENYRGqJbZV4J66aSW4Pg-Mc85RDlp89fXnlp4LbGq8oUHR6O9leIOzq0InSI1RX4WadDvnmqh33E7NhGO04ZNM77So_JLEqBgU4sJEmMFUoedYDTr5lwj2F6NvF5VQ-aprgPErx8yJuatfqv2h-Hpg97kRott63L_BhsM8ydV7xZ-jfjUEuv3Rb-eMdJfWyZgHvjSZmdNhE4ecJzI7k6r_LMiHphOOg40LGCFPs3LQSba9n3xd3jJqCSxoHP0aJyoEww5Q0aoq3BSWE_U4b3QpIi8Rk8bDwh6ACtqYDvuBvIaIj2Mg7N9JQFLBSC-uxAwd5AC7yf2X9oATomXw8JzIVwZYkwyao695HMU0SqNJtz8ssNdAyTU0bf53NsvkTO4D4Xer-zgB43Kl1JkixujFkmU53xBBJ9gBnYJzRm89xpF5F2aXZGc8fxfNBmy2eps39ZHd-kxB1w1LZKiZHkBrtYAvfXSpGP-ZUApxFO5cqYey7STw6DFZd-0xOUhHgDCmFi8u6iRsfm-lF93uHqfvOHhKk7osxvN25I9HDKwhuDWFagwhOXK89lib4hBd4ZluCtkjOY6-38H5fYd6oCj_NrQyC9zWyzHtJuH0BM7_Sn1uQ",
    "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjA4MzUyMjksInR5cGUiOiJhY2Nlc3MiLCJpYXQiOjE3MjA3NDg4MjksImF1ZCI6InRnLmFpLmpvYnMiLCJpc3MiOiJ0Zy5haS5qb2JzIiwic3ViIjoiNzQ1NDI4Nzk0NyIsImp0aSI6Ijk5YmJqbHlpMWZhbGIifQ.FTmodKqVx-cKvmkqvmEuw8nqChzq8unoZYduDIia6eAO0bB1rsNDS7SyFspj_wGkgMISrkvwpWAdQoZRgjO2TTem1QL4tsLe0xAzUFQ7s2mQQ3mst-XddYiQAIpEXwIV0AOv2bzpZWjYYCJwP8m5HQWjtW_L_aOOF3Syy2CiqBWlcZmn6QhRo0pKlM8Ws4JMilRh0z60BUQJkF5JOzBUb_EyrXGWZ6KJh06FSxBBSav9uGM4sJqEDk3NWaEYsPpD9leXEgtW8c6PgTWovh3OadxfYcX5uWgvXxWGYc8MjjI9CItc7acGAo3o_zZbLY-NtNa3WKh2laynFy76Sq0vZLExdTZXkeHVog-6VQwZEzq-kPRBOWYY4XH8GitKplBF3PHGjuWjrurWK4PsZQBLUzNcq1SejtZS68qr96QLgOJiNqnTDoqDu5-IIiG-dwsbL9CztlfYVTm0UfO4woISTXglKi0FIXkDo_FeaFOdR0-n79fjoQBivWHLGb0C4LD_XkKPUYhyQOICUILLM83_xS80SX9tm9O6-YjFZaHJph3Eaesq51UOYNluTLWLp70F3qkQssvLYBHin0orTbRJpW0GNDuZmAEn8QVPbUDfA-msuSOCulh_Z1d16kOuxRAFXwUk_k3jz7LdRES-AKgPz7fhb4_nCvLk1m9NJLWPl_o",
    "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjA4MzUzNzQsInR5cGUiOiJhY2Nlc3MiLCJpYXQiOjE3MjA3NDg5NzQsImF1ZCI6InRnLmFpLmpvYnMiLCJpc3MiOiJ0Zy5haS5qb2JzIiwic3ViIjoiNjczNzQyMzYxOSIsImp0aSI6ImtwYnFxbHlpMWllbTcifQ.vnTErmguBesthGK2ON7MVe7oh7JqYCg0ejUL5528VnVjR8Xgr82D1NfMKPsQ_nD3CP4RCirp_XE_0STq3p5y6BQq21Uas-6KldpCUJ3sMDIGPmSJ5Ncyhgtyt7-0Ltet_6QBLgEQY_5cM5dtdyukjajqPPxmiO-Ogb2YmTstPQk6WxvXeJOWCVMvfLL7i_o5WrO2yogRfqtMg0Oc1giuh55m6XSGykacccOwgvt3ih6cwhjLM3P4QlIjjbhFWHnKf6fXJnd1kEhZ-puy0AdkZW6ZrEGpjA_Qs_iQcpiLHWe5z220OsRVBLX7TlQXu5uw-sFB6lwYyiUkWWxNi80gt_hwOBS2qBcWQdnvu0QLHlty4GpseKULnXh8cB6lhoJSaIQj6UbtFpOft3Di9AJFabQFliUHuycyaC9ZEbdAlRp1GbxWYS8CNbcOlz8Xu270Ln9frFLkUKXjcpLNEZZr1g3JXI2kW8Pw9OvHFiIolY8Rk3aegnmAjQ-xzik03Uf5QCrSm8rHCxKCKlwIMn91EWmGpbYS7Cl7S-5WHq5leJjgZkZQInw_Shi3wMrcd4ANY4W2XLvP6w8O0RAiyBKuEoqnjkEi716S6lvZwJ7PLKAN_TT2QlcxXt8yd9zgvwLuK1-kuZ600zk0dCX8pH6BOPslFZgRNbs9MbgoqnlvKDo",
    "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjA4MzU1NDcsInR5cGUiOiJhY2Nlc3MiLCJpYXQiOjE3MjA3NDkxNDcsImF1ZCI6InRnLmFpLmpvYnMiLCJpc3MiOiJ0Zy5haS5qb2JzIiwic3ViIjoiNjc5NjY5NjMxMyIsImp0aSI6IjRnZjE3bHlpMW0zZnoifQ.ALY9Sv89nSyuKmtavWwcyxikJf-beLdZhh-tSVsIXxje7KXbwSFtn3vR4jZxc0o-QuoyZt6VqHQevNevKqYdnJ_72CAXRydR8JaRR3pqYqBpa5geRDFHtGkTtm4---mP3V32-hMBu8BGz3hYIRv2zEAlIOcFDAkX_9Ghzht9FbroVHx-Bfpf-pD62WzBF7A3afve-Pi5H8mEdfz-TkP4I-qG4uMgpat4o7AdujeDgccbugKQYf6Whn07MNScQgzgWDYpdNi61C1USmRvjESZsZMPecO21pJaszT92VovTmeEDL5UcGKsHtCtmPtyvkueQjrSfgBAh5jFkFNMd-oqjEFUE1o_22TjAAG5t32L-_Xs3MFxzW3IwMTsVLsLY1xNS3IXx1ghGxaX40g9lgf9I8rJ-etsdZeYj44uR1FTTqiXvnPM2oK5dBvBtJ12otlglu-tmaJCVcTmOYEJglEr17WXxeYNBiMy2fB35Hs_v_3GXF7mPfZbN-fV31IB1ZBWeAJfPvpYjHkJ_3RCQrDCqX8xeGmsf5GilpHx_AViXB5QKl2EvEzq4sWpZOS9iwDwRlXpi9F4vEPFRcCY45pruMRiqdwpX-c0HPPuJ_0iAuRMPpI55H7d9ChsSBGrZEh3CfQ1xi-YLTRgpnLBi5mQM9-UVks-6d9h_hpe_lJOmAg"
]
no = ["77", "31", "79", "99"]

headers_template = {
    'Host': 'tg-bot-tap.laborx.io',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://tg-tap-miniapp.laborx.io',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tg-tap-miniapp.laborx.io/',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

json_data = {}

while True:
    error_occurred = False
    for t, n in zip(tg, no):
        headers = headers_template.copy()
        headers['Authorization'] = f'Bearer {t}'

        try:
            response1 = requests.post('https://tg-bot-tap.laborx.io/api/v1/farming/start', headers=headers, json=json_data, verify=False)
            print(n, "started", response1.text)

            response = requests.post('https://tg-bot-tap.laborx.io/api/v1/farming/finish', headers=headers, json=json_data, verify=False)
            print(n, "claimed", response.text)

            response1 = requests.post('https://tg-bot-tap.laborx.io/api/v1/farming/start', headers=headers, json=json_data, verify=False)
            print(n, "started", response1.text)
        except requests.RequestException as e:
            print(f"Error for {n}: {e}")
            error_occurred = True

    if not error_occurred:
        print("Sleep for 2 hr")
        time.sleep(7200)
    else:
        print("Error occurred, retrying immediately")
