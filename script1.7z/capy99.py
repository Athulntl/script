import requests
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...



while True :

 headers = {
    'Host': 'clicker.prod-api.tgquest.com',
    # 'Content-Length': '15',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': 'dXNlcj0lN0IlMjJpZCUyMiUzQTY3OTY2OTYzMTMlMkMlMjJmaXJzdF9uYW1lJTIyJTNBJTIyQWtra3UlMjIlMkMlMjJsYXN0X25hbWUlMjIlM0ElMjJBJTIyJTJDJTIydXNlcm5hbWUlMjIlM0ElMjJhZGtkbWRmJTIyJTJDJTIybGFuZ3VhZ2VfY29kZSUyMiUzQSUyMmVuJTIyJTJDJTIyYWxsb3dzX3dyaXRlX3RvX3BtJTIyJTNBdHJ1ZSU3RCZjaGF0X2luc3RhbmNlPTY1MTY3OTY4ODQ1NzQzODAwNzMmY2hhdF90eXBlPXByaXZhdGUmc3RhcnRfcGFyYW09TVRBNE5qUTBNVEU0TXclM0QlM0QmYXV0aF9kYXRlPTE3MTYxMzA5NzUmaGFzaD0xNjBjZGNhNTk1NmEwOWJkOTdjOTkxYjg3ODFmNGNlNzY2ZWIyYjE2MGVjZTNjYmU0NTFhOWY2OWMyMDAwMjdl',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.52 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://app.tgquest.com',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://app.tgquest.com/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = {
    'count': 15000,
}

 response = requests.post('https://clicker.prod-api.tgquest.com/clicker', headers=headers, json=json_data, verify=False)
 print('99',response.json()['data']['points'])
# Note: json_data will not be serialized by requests
# exactly as it was in the original request.
#data = '{"count":15000}'
#response = requests.post('https://clicker.prod-api.tgquest.com/clicker', headers=headers, data=data, verify=False)
