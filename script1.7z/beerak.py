import requests,time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
while True:


 headers = {
    'Host': 'beer-tg-prod.onrender.com',
    # 'Content-Length': '12',
    'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="126"',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Accept-Language': 'en-US',
    'Sec-Ch-Ua-Mobile': '?0',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.57 Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://beer-tg.web.app',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://beer-tg.web.app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Priority': 'u=1, i',
}

 params = {
    'tgInitData': 'query_id=AAEMzYM0AgAAAAzNgzT-dP8t&user=%7B%22id%22%3A5176020236%2C%22first_name%22%3A%22%F0%9F%98%B6%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22akhil_adg%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1718863270&hash=38b5e67200a1cd562204be25b927fc41cbd748b20c0b598951b6500b61ee7ad9',
}

 json_data = {
    'liters': 1.09,
}

 response = requests.post(
    'https://beer-tg-prod.onrender.com/game/batteryTaps',
    params=params,
    headers=headers,
    json=json_data,
    verify=False,
)
 print("ak",response.json()['balance']['lastBoonAmount'])
 time.sleep(1)

