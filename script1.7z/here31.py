
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...

import requests
import time
while True:
 time.sleep(5)

 headers = {
    'Host': 'api0.herewallet.app',
    # 'Content-Length': '178',
    'Deviceid': '04f065a0-ac93-41db-b6c4-8b9e1f4ffc50',
    'Is-Sbt': 'false',
    'Sec-Ch-Ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Telegram-Data': 'user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-5768264045099933774&chat_type=sender&auth_date=1717427475&hash=3f1e88db7d0bc09f484eaa091697cfcdbd9b5d128436dd1db7b5a72afb35c612',
    'Authorization': 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiI3NDU0Mjg3OTQ3IiwiY2hhdElkIjoiNzQ1NDI4Nzk0NyIsImlhdCI6MTcxNzQyNDY4NCwiZXhwIjoxNzIwMDE2Njg0LCJyb2xlQXV0aG9yaXplcyI6W10sInVzZXJJZCI6MTc5NzYzNTUzNDE0MDM1MDQ2NH0.71X0ivCwHCRgVT5uBmwC0qCOu2uv7_Hd9Kd_6Vr5C5Z-fPqxSiPFMJ_pDiLs0lW9fGOZLIcYp6DpxT8r3zVAgQ',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.118 Safari/537.36',
    'Network': 'mainnet',
    'Content-Type': 'application/json',
    'Platform': 'telegram',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://tgapp.herewallet.app',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tgapp.herewallet.app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Priority': 'u=1, i',
    'Connection': 'close',
}

 json_data = {
    'game_state': {
        'refferals': 0,
        'inviter': 'shmastabrez.tg',
        'village': '126683.village.hot.tg',
        'last_claim': 1715426986377837300,
        'firespace': 0,
        'boost': 10,
        'storage': 20,
        'balance': 50727,
    },
}

 response = requests.post('https://api0.herewallet.app/api/v1/user/hot/claim', headers=headers, json=json_data, verify=False)
 print(response.text)











