import asyncio
import websockets

async def send_message():
    uri = "wss://api-tma.locago.tech/socket.io/?EIO=4&transport=websocket"

    initial_message = '40{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOnsidXVpZCI6IjBiNDZlMjgxLTViZWUtNDNlOS04MmQ3LTMxN2JkNGE2NTIyMCIsInJlZmVycmVkSWRzIjpbIjEiLCIzMSIsIjcxIiwiMjAyIiwiMzM4NSIsIjE0Njk2IiwiMTQ4OTgiLCIxNTI4NyIsIjE4NzY5Il19LCJpYXQiOjE3MjAwOTkzNzQsImV4cCI6MTc1MTY1Njk3NH0.d8GRSyol2QBL4iRL5jOBXyCMnjsra21FDnKktrRsRfc","uuid":"0b46e281-5bee-43e9-82d7-317bd4a65220"}'
    repeating_message = '42["tapping",{"locationId":1679041,"tap":5,"lat":31.24916,"lng":121.48789833333333}]'

    try:
        async with websockets.connect(uri) as websocket:
            # Send the initial message
            await websocket.send(initial_message)
            initial_response = await websocket.recv()
            print(f"Initial response: {initial_response}")
            
            # Enter infinite loop to send the repeating message
            while True:
                await websocket.send(repeating_message)
                response = await websocket.recv()
                print("79",response)
                await asyncio.sleep(1)  # Optional: add a delay between messages
    except websockets.exceptions.InvalidStatusCode as e:
        print(f"Connection failed with status code: {e.status_code}")
        print("Response headers:", e.headers)
    except Exception as e:
        print(f"An error occurred: {e}")

asyncio.run(send_message())
