import requests,time
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
id=["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiQWFhdGh1bGxsIiwic3ViIjoxNDkyOTMsIm9ubHkyRmEiOmZhbHNlLCJpYXQiOjE3MjA4ODkwNjYsImV4cCI6MTcyMDk3NTQ2Nn0.fkCnsb8RpqfLXcfGnRs7vIUJ1UEE1ZJM83zyv3j9550","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiY3J5cHRvb29ib3kiLCJzdWIiOjQxMzA4OCwib25seTJGYSI6ZmFsc2UsImlhdCI6MTcyMDkzMDUxMiwiZXhwIjoxNzIxMDE2OTEyfQ.oSpz17NVu92vwxTugxVw3d4wG1YBaEdzDdIyK3AENlA","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiaW1TYXJhc3dhdGh5Iiwic3ViIjo0MTMxNTMsIm9ubHkyRmEiOmZhbHNlLCJpYXQiOjE3MjA5MzA5ODksImV4cCI6MTcyMTAxNzM4OX0.kwzA8p0lrr2iI5nzKxseew9Iw71cnqe8aAfqI2nh5Bw","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiYWRrZG1kZiIsInN1YiI6NDEzMTcyLCJvbmx5MkZhIjpmYWxzZSwiaWF0IjoxNzIwOTMxMDc2LCJleHAiOjE3MjEwMTc0NzZ9.UrF64v18GNVc5VWDHU4h_jM-t1y4vSOktjrfwr5Lz2Q"]

no=["77","31","79","99"]
while True:
 for i,n in zip(id,no):

  headers = {
    'Host': 'api.fintopio.com',
    # 'Content-Length': '0',
    'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Microsoft Edge";v="126", "Microsoft Edge WebView2";v="126"',
    'Accept': 'application/json, text/plain, */*',
    'Webapp': 'true',
    'Sec-Ch-Ua-Mobile': '?0',
    'Authorization': f'Bearer {i}',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Origin': 'https://fintopio-tg.fintopio.com',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://fintopio-tg.fintopio.com/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Priority': 'u=1, i',
}

  response = requests.post('https://api.fintopio.com/farming/farm', headers=headers, verify=False)
  print(n,response.text)
  response = requests.post('https://api.fintopio.com/farming/claim', headers=headers, verify=False)
  print(n,response.text)
  response = requests.post('https://api.fintopio.com/farming/farm', headers=headers, verify=False)
  print(n,response.text)
 print("sleep for 1 hr")
 time.sleep(3600)
