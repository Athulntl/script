
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...

import requests
import time
while True:
 time.sleep(5)

 headers = {
    'Host': 'api0.herewallet.app',
    # 'Content-Length': '178',
    'Deviceid': '04f065a0-ac93-41db-b6c4-8b9e1f4ffc50',
    'Is-Sbt': 'false',
    'Sec-Ch-Ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Telegram-Data': 'user=%7B%22id%22%3A6737423619%2C%22first_name%22%3A%22Swa%22%2C%22last_name%22%3A%22Am%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=1070897003680776830&chat_type=sender&auth_date=1716013191&hash=8bdf7f04a3a50e3276210441d2af52a40b3320d97745c43540a717f9bd3554fa',
    'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjkxMjI4NjUsImRpZCI6MzY1MDM4OTQsImRldmljZSI6bnVsbCwiYWNjb3VudF9pZCI6IjY3Mzc0MjM2MTkudGciLCJkZXZpY2VfaWQiOiI4OWU2MDI4Ny04ZjNjLTRkOGEtODczMC01YjQxNGY3YjEwNzIiLCJwbGF0Zm9ybSI6InRlbGVncmFtIiwidGltZXN0YW1wIjoxNzE2MDEzMTI4LjAsInZpZXdfb25seSI6ZmFsc2V9.vPgPfKUDH-fcr0eaJXwdDaxxJsvnP1FiGkE8kNDJGU0',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.118 Safari/537.36',
    'Network': 'mainnet',
    'Content-Type': 'application/json',
    'Platform': 'telegram',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Accept': '*/*',
    'Origin': 'https://tgapp.herewallet.app',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tgapp.herewallet.app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Priority': 'u=1, i',
    'Connection': 'close',
}

 json_data = {
    'game_state': {
        'refferals': 0,
        'inviter': 'aaathulll.tg',
        'village': '126683.village.hot.tg',
        'last_claim': 1715426986377837300,
        'firespace': 0,
        'boost': 10,
        'storage': 20,
        'balance': 50727,
    },
}

 response = requests.post('https://api0.herewallet.app/api/v1/user/hot/claim', headers=headers, json=json_data, verify=False)
 print(response.text)
