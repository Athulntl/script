import requests
while True :

# Define the request headers and body
 headers = {
    "Host": "api.empiresbattle.com",
    "Content-Length": "10",
    "Sec-Ch-UA": "\"Google Chrome\";v=\"125\", \"Chromium\";v=\"125\", \"Not.A/Brand\";v=\"24\"",
    "Content-Type": "application/json",
    "Sec-Ch-UA-Mobile": "?1",
    "Authorization": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3MTcxODcwMDYuNTE5Njc2LCJleHAiOjE3MTk3NzkwMDYuNTE5NjgzLCJ1aWQiOjE0MDYzOCwic2VjcmV0IjoiZmlPMUtieGZ6YnYxYzNlNVFlSkRfcENHMnFDYk9ST18ifQ.iARnhJEeUSY8KbrLZky0uRTU53nAsgl5x_kDcOMftxU",
    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
    "Sec-Ch-UA-Platform": "\"Android\"",
    "Accept": "*/*",
    "Origin": "https://app.empiresbattle.com",
    "Sec-Fetch-Site": "same-site",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Dest": "empty",
    "Referer": "https://app.empiresbattle.com/",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7,ml;q=0.6",
    "Priority": "u=1, i"
}
 data = {"taps": 800}

# Make the POST request
 response = requests.post("https://api.empiresbattle.com/v1/tapper/add", json=data, headers=headers)

# Print the response
 print(response.text)
