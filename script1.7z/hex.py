import requests,time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
no=["77","79","99","31"]
id=[1086441183,6737423619,6796696313,7454287947]
tg=["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxMDg2NDQxMTgzLCJ1c2VybmFtZSI6IkFhYXRodWxsbCIsInRpbWVzdGFtcCI6MTcxOTU4MTgwNC4yMjAwMzF9.8Yh3FWprdsqzhnEvoZHxdWRN_xp3qBTqlLG0_GPbKOk","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjo3NDU0Mjg3OTQ3LCJ1c2VybmFtZSI6ImNyeXB0b29vYm95IiwidGltZXN0YW1wIjoxNzE5NTgxOTY4LjE3NTU0NDV9.dAeQlS-0dH4ZeeMhh3wsq_Oir4CoLNIbEdRzG-mT-hQ","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjo2NzM3NDIzNjE5LCJ1c2VybmFtZSI6ImltU2FyYXN3YXRoeSIsInRpbWVzdGFtcCI6MTcxOTU4MjI0MS4wODkzMzg1fQ.un5AxlCfWyibAfDjysPWP4eIzp42zsDQULkC3l-Y3Xo","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjo2Nzk2Njk2MzEzLCJ1c2VybmFtZSI6ImFka2RtZGYiLCJ0aW1lc3RhbXAiOjE3MTk1ODIzNjIuOTk0Mzc4M30._snhHuZFUpOwjWXpR7IprERKlMIX7Nn57pIeiWJ62ZU"]
while True:
 for ii,n,t in zip(id,no,tg):
  for i in range(1,101):
 
   headers = {
    'Host': 'ago-api.onrender.com',
    # 'Content-Length': '12',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': t,
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://ago-wallet.hexacore.io',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://ago-wallet.hexacore.io/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}



   headers1 = {
    'Host': 'ago-api.onrender.com',
    # 'Content-Length': '47',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://ago-wallet.hexacore.io',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://ago-wallet.hexacore.io/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}
   json_data = {
    'taps': 100,
}

   json_data1 = {
    'user_id': ii,
}

   json_data2 = {
    'game_id': i,
    'user_id': ii,
}
   json_data3 = {
    'name': '7_days',
}

   response3 = requests.post('https://ago-api.onrender.com/api/buy-tap-passes', headers=headers, json=json_data3, verify=False)
   response = requests.post('https://ago-api.onrender.com/api/mining-complete', headers=headers, json=json_data, verify=False)
   response1 = requests.post('https://ago-api.onrender.com/api/daily-reward', headers=headers1, json=json_data1, verify=False)
   response2 = requests.post('https://ago-api.onrender.com/api/in-game-reward', headers=headers, json=json_data2, verify=False)
   responseb = requests.get(f'https://ago-api.onrender.com/api/balance/{ii}', headers=headers, verify=False)
  print(n,responseb.json()['balance'])
 print("sleep for 6 hr")
 time.sleep(21600)