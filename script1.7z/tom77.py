import requests,time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
while True:

 cookies = {
    '__Host-authjs.csrf-token': '16170c04f98cb99d8fb907e1d6ed1156984d7dba22cd1f57e9b1b93e86313795%7C70c66628665f17bb398131620edfcc2d1d3339ad95a5fe26a64a5594a7c904b7',
    '__Secure-authjs.callback-url': 'https%3A%2F%2Fapp.tomcoin.app%2F%3FidUser%3D1086441183%26idRef%3D1086441183',
    '__Secure-authjs.session-token': 'eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..Nl4a4oLL9uFStkBN.cYbai4YysozQPSwGTz7quY88qI-oFaXfM7ZkNWOr3gc8aN8VRmY_kxPVRAi5689xrXpMgP2B9cm5psf41rSiPrYvd7Rd9VFY5vkS8c06Xk21H2f2fYmIPVzcZc9g2FL4cpaCoPdW8xm9Dk1RPkucYYXBVnjrvL0WVYxtTIsVgOpAOcfwpn-rd28F-bxQL5WUbMig4G-uWpJVQhft0TeWATunN3xROFoKUYvnakZlDpH1xtx7ixE8ej7CeM2zUgz3DCGWAW6nBh9pMK6N9Q4cM3kNiHQkH5MjpY7Y-wdMT2rApspjRRyzIiEEDN-5rkDPrY5AoXIHrcO20pNFL7mN5-g55qW-qM_flb2eCUyhQIpyqT5focSKdzxi2GejrKOR7ec8AKBtMNj9-hY9FH7U0yDg0iF6TqKcngWFj7AQN0IWsKc0wto6FUXyfvf_TI1JCPjQFTsXPU6xnyumYgFmF9B30zbqs9EAew.SjY3CptCWoFzmoZmI5REuw',
}

 headers = {
    'Host': 'app.tomcoin.app',
    # 'Content-Length': '27',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Next-Router-State-Tree': '%5B%22%22%2C%7B%22children%22%3A%5B%22__PAGE__%3F%7B%5C%22idUser%5C%22%3A%5C%221086441183%5C%22%2C%5C%22idRef%5C%22%3A%5C%221086441183%5C%22%7D%22%2C%7B%7D%5D%7D%2Cnull%2Cnull%2Ctrue%5D',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Content-Type': 'text/plain;charset=UTF-8',
    'Accept': 'text/x-component',
    'Next-Action': '12fd83780d97281c2b5217bb8f7f5bb4af437906',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://app.tomcoin.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://app.tomcoin.app/?idUser=1086441183&idRef=1086441183',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 params = {
    'idUser': '1086441183',
    'idRef': '1086441183',
}
 proxies = {
    'http': 'http://127.0.0.:8080',
    'https': 'http://127.0.0.1:8080',
}
 data = '["1086441183","1086441183"]'

 response = requests.post('https://app.tomcoin.app/', params=params, cookies=cookies, headers=headers, data=data, verify=False)
# print(response.text)



 headers1 = {
    'Host': 'app.tomcoin.app',
    # 'Content-Length': '70',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://app.tomcoin.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://app.tomcoin.app/?idUser=1086441183&idRef=747206395',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',

}

 json_data2 = {
    'data': {
        'userId': '1086441183',
        'clickPoints': 400,
        'passivePoints': 400,
    },
}
 json_data1 = {
    'userId': '1086441183',
    'claimType': [
        6,
    ],
    'claimablePoints': 1,
}
 response1 = requests.post('https://app.tomcoin.app/api/game/claim-reward', cookies=cookies, headers=headers1, json=json_data1, verify=False)
 response2 = requests.post('https://app.tomcoin.app/api/profile/save', cookies=cookies, headers=headers1, json=json_data2, verify=False)
 print("77",response1.text)
 print("77",response2.text)
 time.sleep(10)
