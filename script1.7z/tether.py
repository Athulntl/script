import requests,time
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
tg=["user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=4251669336773092158&chat_type=sender&start_param=51HE3BU&auth_date=1721137582&hash=9290616b780617c6f91d1da42ac18356214199b38080b6b14c4eeec31e7a3064","user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22cryptoooboy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=1705331807391584111&chat_type=sender&start_param=MG9LKU3&auth_date=1721137832&hash=22181fb82f0a2e161663f7cad2b4afff0058ddd174f292e26f6ff87f7c32ec40","user=%7B%22id%22%3A6737423619%2C%22first_name%22%3A%22Swa%22%2C%22last_name%22%3A%22Am%22%2C%22username%22%3A%22imSaraswathy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=6983782613724073130&chat_type=sender&start_param=MG9LKU3&auth_date=1721137883&hash=b88863fc3bd208b30cec7650440aa5d55f81887b09a3d35e2deccdbbf45e979b","user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-7912279858452394706&chat_type=sender&start_param=MG9LKU3&auth_date=1721137913&hash=9f4f60a286ab9ba4231e78a4821eaf36548daa18448eb336ca6cff4d5d794f5f"]
no=["77","31","79","99"]
while True:
 for t,n in zip(tg,no):
 
 
 
  headers = {
    'Host': 'tap-tether.org',
    'Access-Control-Allow-Origin': '*',
    'Accept': 'application/json, text/plain, */*',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'tma {t}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tap-tether.org/?tgWebAppStartParam=51HE3BU',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

  params = {
    'clicks': '1000',
    'lastClickTime': int(time.time()),
}

  response = requests.get('https://tap-tether.org/server/clicks', params=params, headers=headers, verify=False)
  print(n,response.text)
 time.sleep(1000)
