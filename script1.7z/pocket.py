import requests,time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
list=["query_id=AAHfxsFAAAAAAN_GwUBXOYQO&user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1719595677&hash=9d6ff9d9f35a3cca588e54ad5f1c6d9102679c09c133d846cc522b21195d7ccf","user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22cryptoooboy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-4968600592742185487&chat_type=private&start_param=1086441183&auth_date=1719674035&hash=bf4fb0342d7ded12a42ac67b9488aac4de3d42e515386291331a7efa1664a500","user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=6365395234395012372&chat_type=private&start_param=1086441183&auth_date=1719674334&hash=731bb109b184a2dc767718fa84c438251b668ffcf11c589e2827a5da43f1867a","user=%7B%22id%22%3A6737423619%2C%22first_name%22%3A%22Swa%22%2C%22last_name%22%3A%22Am%22%2C%22username%22%3A%22imSaraswathy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=58175501689772383&chat_type=private&start_param=1086441183&auth_date=1719674405&hash=3a2cd8d81ba111302fc9c9ae6c61a5ed8cdafee5adc4ded97651c85478486fc7"]
while True:
 for a in list:

  headers = {
    'Host': 'bot.pocketfi.org',
    # 'Content-Length': '0',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Telegramrawdata': a,
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://pocketfi.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://pocketfi.app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
    'Connection': 'keep-alive',
}
  response1 = requests.post('https://bot.pocketfi.org/boost/activateDailyBoost', headers=headers, verify=False)
  response = requests.post('https://bot.pocketfi.org/mining/claimMining', headers=headers, verify=False)
  
  print(response.text)
 print("sleep for 1 hr")
 time.sleep(3600)