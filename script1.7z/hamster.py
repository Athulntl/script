import requests
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
import time
# Your existing code here...
tg=["1718367479737Yn8ubFaoIdJ3ewPojEOm8fJpdLHZB0AE3Yzu1NEHCIRwBGDcRCk8kZhEBGavPOMH5176020236","1720021616216RdWfPUP7UVRwpF8tn5yCXtlaux3Ypd8eAt9FRaozyAYF30hnB9EmEl483BwEpWzc1086441183","1715873204715p5wDp6nCNbVyUgyiws91oqAJU6DL4O69jarew9x6cSJIJjQ0gxVUmARTIF94OoxX6737423619","1715872421386x112pzCPtXtp7YacaMyRr78Rp69F5hlTcjt5U57vY0kCd2khYHnWFJKoToxsi2YA6796696313","1717422858860PeIv1th3kI3r0Pt7jqDBFt05tHwo1LECtrxZ1tLpMEvXOrFolR3ZKIX994w2TBgz7454287947","1718806270895sj9gOxf7J5W0R6vkNW4ZhnjzZxWloC3BDOjMN9q5BrpXPTeHTu0lrNHuxkQnQb6v928159758","1718463598187O0NE8QOmOonGyhZMGFb1dJLqsfBhifqPvhIZXK4ASoCbLwJz8VALWvBsNIymHkqk6619379408"]
no=["ak","77","79","99","31","as","ab"]

while True :
 for t,n in zip(tg,no):
 
  headers = {
    'Host': 'api.hamsterkombatgame.io',
    # 'Content-Length': '0',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {t}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.52 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://hamsterkombat.io',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://hamsterkombatgame.io/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

  response = requests.post('https://api.hamsterkombatgame.io/clicker/sync', headers=headers, verify=False)


  headers1 = {
    'Host': 'api.hamsterkombatgame.io',
    # 'Content-Length': '58',
    'Sec-Ch-Ua': '"Chromium";v="124", "Android WebView";v="124", "Not-A.Brand";v="99"',
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {t}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.6367.161 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://hamsterkombat.io',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://hamsterkombatgame.io/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

  json_data1 = {
    'count': 100,
    'availableTaps': 6000,
    'timestamp': 1720264650,
}
  json_data = {
    'taskId': 'streak_days',
} 
  response = requests.post('https://api.hamsterkombatgame.io/clicker/check-task', headers=headers, json=json_data, verify=False)
  response1 = requests.post('https://api.hamsterkombatgame.io/clicker/tap', headers=headers1, json=json_data1, verify=False)
  print(n,response1.json()['clickerUser']['balanceCoins'],"available",response1.json()['clickerUser']['availableTaps'])
  
 
 time.sleep(100)












