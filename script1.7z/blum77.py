import requests
import time
while  True:
# time.sleep(28800)
 headers = {
    'Host': 'game-domain.blum.codes',
    # 'Content-Length': '0',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Accept': 'application/json, text/plain, */*',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJoYXNfZ3Vlc3QiOmZhbHNlLCJ0eXBlIjoiQUNDRVNTIiwiaXNzIjoiYmx1bSIsInN1YiI6IjcxMTdiZWY5LWQ2ZWMtNDZmYi1iMDZjLTkxZDg4MGRjZDU5OCIsImV4cCI6MTcxNjY5MzQ2NiwiaWF0IjoxNzE2Njg5ODY2fQ.4HfhlOM8-_Tv6mPhJUZcBNJ4T5EYqe9-tWFo2gIGk2Y',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.52 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://telegram.blum.codes',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://telegram.blum.codes/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 response = requests.post('https://game-domain.blum.codes/api/v1/farming/claim', headers=headers, verify=False)
 print(response.text)
 time.sleep(28800)
