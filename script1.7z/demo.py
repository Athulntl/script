import os
os.remove('/data/data/com.termux/files/home/downloads/b')
