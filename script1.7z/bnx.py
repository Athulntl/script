import requests,time
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
tg=["0764ac59a38865c4ec0a8cdf3d8e44d3bf4f2278bfd9903c079562fb62af9e1f","c413365cde84c3ed8cbe87faf6ad46950afd0b7c71339944c10f7666a7b50431","4bba88975f9dd540d3afc36180cbaa3330de9bb4cafb219efc375cfccc79b6d1","3823931b3729c7095b851e459616c859752dfd456b0138af71b8e478a5a72ab8"]
no=["77","31","79","99"]
while True:
 for t,n in zip(tg,no):


  headers = {
    'Host': 'backend.got.bondex.app',
    # 'Content-Length': '11',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'X-Api-Key': t,
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://got.bondex.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://got.bondex.app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
    'Connection': 'keep-alive',
}

  json_data = {
    'count': 300,
}

  response = requests.post('https://backend.got.bondex.app/mine', headers=headers, json=json_data, verify=False)
  response1 = requests.post('https://backend.got.bondex.app//pickDailyBonus', headers=headers, json=json_data, verify=False)
  print(n,response.text)
time.sleep(100)
