import requests,time

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
id=["1086441183","6737423619","6796696313","7454287947"]
no=["77","31","99","79"]

while True:
 for i,n in zip(id,no):
  headers = {
    'Host': 'richdesk.io',
    'Connection': 'keep-alive',
    # 'Content-Length': '13',
    'sec-ch-ua': 'Not/A',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua-mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 12; M2101K6P Build/SKQ1.210908.001) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.71 Mobile Safari/537.36',
    'sec-ch-ua-platform': 'Android',
    'Origin': 'https://richdesk.io',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://richdesk.io/',
    # 'Accept-Encoding': 'gzip, deflate, br, zstd',
    'Accept-Language': 'en-IN,en-US;q=0.9,en;q=0.8',
}

  data = {
    'id': i,
} 
  data1 = {
    'id': i,
    'num': '1',
} 
  requests.post('https://richdesk.io/wp-content/questClear.php', headers=headers, data=data1, verify=False)
  response1 = requests.post('https://richdesk.io/wp-content/mainInit.php', headers=headers, data=data, verify=False)
  if(response1.json()['hcval']>=79):
    requests.post('https://richdesk.io/wp-content/immediateCool.php', headers=headers, data=data, verify=False)
    print(n,"cool upgraded")
  if(response1.json()['totalStorage']>=95):
    requests.post('https://richdesk.io/wp-content/immediateUsb.php', headers=headers, data=data, verify=False)
    print(n,"storage upgraded")
   
  response = requests.post('https://richdesk.io/wp-content/claim.php', headers=headers, data=data, verify=False)
  response1 = requests.post('https://richdesk.io/wp-content/mainInit.php', headers=headers, data=data, verify=False)
  print(n,"Balance",response1.json()['currentDesk'])
 time.sleep(60)








