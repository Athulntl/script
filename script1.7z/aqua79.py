import requests,time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
#while True:

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
while True:
 headers = {
    'Host': 'api.gleam.bot',
    # 'Content-Length': '433',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Accept': 'application/json, text/plain, */*',
    'Ngrok-Skip-Browser-Warning': '69420',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.52 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://aquaprotocol.gleam.bot',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://aquaprotocol.gleam.bot/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = {
    'startedAt': 1716693577936,
    'initData': 'user=%7B%22id%22%3A6737423619%2C%22first_name%22%3A%22Swa%22%2C%22last_name%22%3A%22Am%22%2C%22username%22%3A%22imSaraswathy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-6108103424544963021&chat_type=private&start_param=cmM9MzA0OTIzYzQ&auth_date=1716693838&hash=2f5243b4e99d0e1ea67a991e7cb6142a9844f2f8066bc4a2aa0ad641c768f056',
    'project': 'Aqua Protocol',
}

 response = requests.post('https://api.gleam.bot/start-farming', headers=headers, json=json_data, verify=False)
 print(response.text
 time.sleep(28800)
# Note: json_data will not be serialized by requests
# exactly as it was in the original request.
#data = '{"startedAt":1716693577936,"initData":"user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=5976539529405171694&chat_type=channel&start_param=cmM9MTM3NDczMmY&auth_date=1716693558&hash=593e05fac6d2cd0dcccea305a9eaf1fcb75c3eb7cb57d0580bdd421f360f3130","project":"Aqua Protocol"}'
#response = requests.post('https://api.gleam.bot/start-farming', headers=headers, data=data, verify=False)







