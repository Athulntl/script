import requests
import time
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from datetime import datetime
import threading

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Function to send request1 every 600 seconds
def send_request1():
    headers = {
        'Host': 'api.chickcoop.io',
        'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
        'Content-Type': 'application/octet-stream',
        'Sec-Ch-Ua-Mobile': '?1',
        'Authorization': 'user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22cryptoooboy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-8083895129880677486&chat_type=private&start_param=ref_1086441183&auth_date=1718995680&hash=80ca234bb59266afaca5be49bdddbecf9b3433663b3a874aceee1d7e8ce8ede9',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
        'Sec-Ch-Ua-Platform': '"Android"',
        'Accept': '*/*',
        'Origin': 'https://game.chickcoop.io',
        'X-Requested-With': 'org.telegram.messenger',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://game.chickcoop.io/',
        'Accept-Language': 'en,en-US;q=0.9',
        'Priority': 'u=1, i',
    }
    try:
        response = requests.post('https://api.chickcoop.io/gift/claim', headers=headers, verify=False)
        # Log timestamp and response details
        print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}]")
        print("31 Error (request1):", response.json().get('error', 'No error key found'))
        print("31 Response (request1):", response.text)
    except Exception as e:
        print(f"An error occurred (request1): {e}")

# Function to send request2 every 3 seconds
def send_request2():
    headers = {
        'Host': 'api.chickcoop.io',
        'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
        'Content-Type': 'application/octet-stream',
        'Sec-Ch-Ua-Mobile': '?1',
        'Authorization': 'user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22cryptoooboy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-8083895129880677486&chat_type=private&start_param=ref_1086441183&auth_date=1718995680&hash=80ca234bb59266afaca5be49bdddbecf9b3433663b3a874aceee1d7e8ce8ede9',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
        'Sec-Ch-Ua-Platform': '"Android"',
        'Accept': '*/*',
        'Origin': 'https://game.chickcoop.io',
        'X-Requested-With': 'org.telegram.messenger',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://game.chickcoop.io/',
        'Accept-Language': 'en,en-US;q=0.9',
        'Priority': 'u=1, i',
    }
    try:
        response = requests.post('https://api.chickcoop.io/hatch/manual', headers=headers, verify=False)
        # Log timestamp and response details
        print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}]")
        print("31 Chickens quantity (request2):", response.json()['data']['chickens']['quantity'])
    except Exception as e:
        print(f"An error occurred (request2): {e}", response.text)

# Function to run request1 periodically
def run_request1_periodically():
    send_request1()
    threading.Timer(600, run_request1_periodically).start()

# Function to run request2 periodically
def run_request2_periodically():
    send_request2()
    threading.Timer(3, run_request2_periodically).start()

# Start the periodic requests
run_request1_periodically()
run_request2_periodically()
