import requests
import  time

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...

while True:
# time.sleep(1)
 

 headers = {
    'Host': 'api.yescoin.gold',
    # 'Content-Length': '1',
    'Sec-Ch-Ua': '"Chromium";v="124", "Android WebView";v="124", "Not-A.Brand";v="99"',
    'Accept': 'application/json, text/plain, */*',
    # Already added when you pass json=
    # 'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.6367.161 Mobile Safari/537.36',
    'Token': 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiI2NzM3NDIzNjE5IiwiY2hhdElkIjoiNjczNzQyMzYxOSIsImlhdCI6MTcxODY3MTU1MCwiZXhwIjoxNzIxMjYzNTUwLCJyb2xlQXV0aG9yaXplcyI6W10sInVzZXJJZCI6MTc5MDk1MDE0MzEyMzI4ODA2NH0.EAcQS9xcwOIVGP582a-LqPXIeBYUCYLuCCaH8xyS_kHhJG_1GegTVyXgUPJbUYxIjN0ZrEvl1IbDoRUvGILWmQ',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://www.yescoin.gold',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://www.yescoin.gold/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = 300

 response = requests.post('https://api.yescoin.gold/game/collectCoin', headers=headers, json=json_data, verify=False)
 
 response1= requests.post('https://api.yescoin.gold/game/recoverCoinPool',headers=headers,verify=False)
 print('79',response.text,response1.text)
 time.sleep(300)














