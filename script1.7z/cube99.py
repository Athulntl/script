
import requests                                                             
# import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
import  time
# Your existing code here...



while True:

 def refill():
  import requests
                                                                                   
  headers = {
    'Host': 'server.questioncube.xyz',
    # 'Content-Length': '92',
    'Sec-Ch-Ua': '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    'Content-Type': 'application/json',                                              'Accept': '*/*',                                                                 
    'Origin': 'https://www.thecubes.xyz',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://www.thecubes.xyz/',                                          
# 'Accept-Encoding': 'gzip, deflate, br',                                        
    'Accept-Language': 'en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7,ml;q=0.6',
    'Priority': 'u=1, i',                                                      }                                                                          
  json_data = {
    'token': 'e2b25ed91fa1f522b0e92f8aa4f3d7a2e62970a0ecf51ebddf9476d4c2c98f1c',     
    'proposal_id': 2,
}

  response = requests.post('https://server.questioncube.xyz/game/rest-proposal/buy', headers=headers, json=json_data, verify=False)                                 
  print('refilled')
 # Note: json_data will not be serialized by requests
# exactly as it was in the original request.
#data = '{"token":"68a3dce9f8112de5029d1bbaee5b7122d6f434aeb2f5a83947a15d74aa710cec","proposal_id":4}'
#response = requests.post('https://server.questioncube.xyz/game/rest-proposal/buy', headers=headers, data=data, verify=False)
 def req():
# while True:
   time.sleep(5)
   headers = {
    'Host': 'server.questioncube.xyz',
    # 'Content-Length': '76',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.52 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://www.thecubes.xyz',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://www.thecubes.xyz/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

   json_data = {
    'token': '68a3dce9f8112de5029d1bbaee5b7122d6f434aeb2f5a83947a15d74aa710cec',
}

   response = requests.post('https://server.questioncube.xyz/game/mined', headers=headers, json=json_data, verify=False)
   print('77',response.text)
   try:
    energy=response.json()['energy']
    drop=response.json()['drops_amount']
   # print(energy,drop
    if type(energy)!=str or type(drop)!=str:
      req()
    return (energy,drop)
   except:
    print("no energy fetched")
    req()
#   energy=int(energy)
    
    #return (energy,drop)
 try :
  e,d=req()
 except:
     e,d=req()
 e=int(e)
 print('energy',e,'drop',d)
 e=int(e)
 d=int(d)
 print('trying to refill')
 if e <= 200 and d >= 125:
    print("waiting for 60 sec")
    print('energy',e ,'drop',d)
    time.sleep(60)
    refill()
    print('refilled less than 200')
 elif e <= 200 and d < 125:
      print("waiting for 300 sec")
      print('energy',e ,'drop',d)
      time.sleep(300)
      req()
     # print('')
     # print('77',response.text)
 elif e>200 and d>=125:
      print('refilled greater than 200')
      refill()

