import requests,time
while True:
 headers = {
    'Host': 'app2.firecoin.app',
    # 'content-length': '16',
    'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Android WebView";v="126"',
    'sec-ch-ua-mobile': '?1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 12; M2101K6P Build/SKQ1.210908.001) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.71 Mobile Safari/537.36',
    'authorization': 'tma query_id=AAHfxsFAAAAAAN_GwUAb7V0J&user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1719166030&hash=24498555b90fd2acac3db190b3b73638f2d34e2eb84c904b3decdb6c4eb48248',
    'content-type': 'text/plain;charset=UTF-8',
    'baggage': 'sentry-environment=production,sentry-release=b2efb2084e8d46a3928de5b0e31134b6,sentry-public_key=b0fc3814fb3f0f1e101c09858d373091,sentry-trace_id=88fa2b7852a1452cbee2e49e52e0c54d',
    'sentry-trace': '88fa2b7852a1452cbee2e49e52e0c54d-a737f80815bf03b8',
    'sec-ch-ua-platform': '"Android"',
    'accept': '*/*',
    'origin': 'https://app2.firecoin.app',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://app2.firecoin.app/',
    # 'accept-encoding': 'gzip, deflate, br, zstd',
    'accept-language': 'en-IN,en-US;q=0.9,en;q=0.8',
    'priority': 'u=1, i',
}

 data = '{"clicks": 102927477}'

 response = requests.post('https://app2.firecoin.app/api/click', headers=headers, data=data)
 print(response.text)
 time.sleep(5)
