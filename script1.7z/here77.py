
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...

import requests
import time
while True:
 time.sleep(5)

 headers = {
    'Host': 'api0.herewallet.app',
    # 'Content-Length': '178',
    'Deviceid': '04f065a0-ac93-41db-b6c4-8b9e1f4ffc50',
    'Is-Sbt': 'false',
    'Sec-Ch-Ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Telegram-Data': 'user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=281816407986919622&chat_type=sender&auth_date=1715436220&hash=2f93ee7cbdda46cfe3d9bdc4badd52b3694d14a889ec4dad0daaaaa5a9f8f193',
    'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjg0NDkxNDQsImRpZCI6MzA5NTM2MTYsImRldmljZSI6bnVsbCwiYWNjb3VudF9pZCI6ImFhYXRodWxsbC50ZyIsImRldmljZV9pZCI6IjA0ZjA2NWEwLWFjOTMtNDFkYi1iNmM0LThiOWUxZjRmZmM1MCIsInBsYXRmb3JtIjoidGVsZWdyYW0iLCJ0aW1lc3RhbXAiOjE3MTQ5NTY1NjguMCwidmlld19vbmx5IjpmYWxzZX0.6y1BTq0JyNscTsNEwHDbAtNBTlcohJlJq2WabMOVa_s',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.118 Safari/537.36',
    'Network': 'mainnet',
    'Content-Type': 'application/json',
    'Platform': 'telegram',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Accept': '*/*',
    'Origin': 'https://tgapp.herewallet.app',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tgapp.herewallet.app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Priority': 'u=1, i',
    'Connection': 'close',
}

 json_data = {
    'game_state': {
        'refferals': 0,
        'inviter': 'shmastabrez.tg',
        'village': '126683.village.hot.tg',
        'last_claim': 1715426986377837300,
        'firespace': 0,
        'boost': 10,
        'storage': 20,
        'balance': 50727,
    },
}

 response = requests.post('https://api0.herewallet.app/api/v1/user/hot/claim', headers=headers, json=json_data, verify=False)
 print(response.text)
