import subprocess
import time

def run_programs():
    processes = []
    # Replace 'program_to_run_1.py', 'program_to_run_2.py', and 'program_to_run_3.py'
    # with the names of your Python programs
    for program in [ 'slap77.py','slap79.py','slap99.py','slap31.py']:
        process = subprocess.Popen(['python', program])
        processes.append(process)
    return processes

def kill_programs(processes):
    for process in processes:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()

def main():
    while True:
        # Run the programs
        processes = run_programs()
#        print("killed")
        # Wait for some time (e.g., 10 seconds)
        time.sleep(30)
        print("killed")       
        # Kill the programs
        kill_programs(processes)

if __name__ == "__main__":
    main()
