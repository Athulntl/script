import requests,time

from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
no=["77","31","79","99"]
cook=["GS1.1.1719667337.1.0.1719667337.0.0.0","GS1.1.1719835160.2.1.1719836177.0.0.0","GS1.1.1719836872.1.0.1719836872.0.0.0","GS1.1.1719836872.1.1.1719837007.0.0.0"]
tg=["user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=8466114468298296838&chat_type=sender&auth_date=1719667335&hash=9a9b97117c6d8014a12e1b0784fceb16fe1e3423d606cf57c0c7719cecbdc3e7","user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22cryptoooboy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=9186395592151141311&chat_type=private&start_param=ref-66800a68c3861875752d9db1&auth_date=1719836178&hash=922acf3f5c300dcd654d63b89d5cf79f90950238d1513c12afc1eb6ca2b99e11","user=%7B%22id%22%3A6737423619%2C%22first_name%22%3A%22Swa%22%2C%22last_name%22%3A%22Am%22%2C%22username%22%3A%22imSaraswathy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=6427313594882292211&chat_type=private&start_param=ref-66800a68c3861875752d9db1&auth_date=1719836871&hash=c924da2514f4ccec4eb553e9eeb81ad20b8f1584287c6df21e9b10dac300491e","user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=6772590343553313550&chat_type=private&start_param=ref-66800a68c3861875752d9db1&auth_date=1719837008&hash=d9da30fa68eb2ddfc24a95136dd4fcb0a475c99cac792b8989b05765e854a46f"]
while True:
 for c,t,n in zip(cook,tg,no):
 


  cookies = {
    '_ga': 'GA1.1.2109592889.1719667338',
    '_ga_35M86WVDVQ': c,
}

  headers = {
    'Host': 'bot.dragonz.land',
    # 'Content-Length': '15',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'X-Init-Data': t ,
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://bot.dragonz.land',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://bot.dragonz.land/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

  json_data = {
    'feedCount': 1000,
}

  json_data2 = {
    'boostKey': 'passive-feed',
}
 

  json_data3 = {
    'boostKey': 'daily-energy-recharge',
}
 

  json_data4 = {
    'taskKey': 'daily-post-like-and-retweet',
}
 

  json_data5 = {
    'taskKey': 'daily-claim',
}

  response = requests.post('https://bot.dragonz.land/api/me/feed', cookies=cookies, headers=headers, json=json_data, verify=False,)
  response1 = requests.get('https://bot.dragonz.land/api/me', cookies=cookies, headers=headers, verify=False,)
  response2 = requests.post('https://bot.dragonz.land/api/me/boosts/buy',cookies=cookies,headers=headers,json=json_data2,verify=False,)
  response3 = requests.post('https://bot.dragonz.land/api/me/boosts/buy',cookies=cookies,headers=headers,json=json_data3,verify=False,)
  response4 = requests.post('https://bot.dragonz.land/api/me/tasks/verify',cookies=cookies,headers=headers,json=json_data4,verify=False,)
  response5 = requests.post('https://bot.dragonz.land/api/me/tasks/verify',cookies=cookies,headers=headers,json=json_data5,verify=False,)
  try:
    print(n,response1.json()['coins'])
    time.sleep(10)
  except:
    print("RESTART")














