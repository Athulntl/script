import requests,time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
while True:

 cookies = {
    '__Secure-authjs.callback-url': 'https%3A%2F%2Fapp.tomcoin.app%2F%3FidUser%3D7454287947%26idRef%3D1086441183',
    '__Host-authjs.csrf-token': '16170c04f98cb99d8fb907e1d6ed1156984d7dba22cd1f57e9b1b93e86313795%7C70c66628665f17bb398131620edfcc2d1d3339ad95a5fe26a64a5594a7c904b6',
    '__Secure-authjs.session-token': 'eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..L-u9WxzlzPID0xSF.regQzj3U8tUKPPJ766bvZQmZcVtvHeFYzUswrF0Jcil9ud_RCgRAbQWV3WvneKM4y08GdwYTLsDkrojpkEAzBpjt01BkRMPnfE0TWCKmNAYphuOhRDXgLxcy-OLOTJHkdQ-kjVsFh0r3BndqoaE06DrAwcHHg3SShB3Kcwo60Bp1DmY66CKLm9v_erRo01Iz8LJ7b__wfvBcWiFPw6UiblN5bqrwQxtOJBK9aQXlv_Gk_maFrmF5z5Qq30hLks_w8VUM5jgG8cztqlTBuFMer3Tx20ASHQE2nnBdvJZsssi8RGtHKRzxSdLDL2klGcDgyJfBI-X--zxHnMIxxP8GhSArBTVuylYAImwvwKl3bc1w9BfPR7ehRK9SobsoeZdX86HsdwLToM_dEWHQiNLiXYBpVReMr4R4vhDnW2i10oxL8vgRVfvVi2fKnWKpVc7PSvkQTId4Rf3zYxNieSaL_Gbq8KKghojuxZnCAjbu.bQXzaWiI2lijBy4KKjFi8w',
}

 headers = {
    'Host': 'app.tomcoin.app',
    # 'Content-Length': '27',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Next-Router-State-Tree': '%5B%22%22%2C%7B%22children%22%3A%5B%22__PAGE__%3F%7B%5C%22idUser%5C%22%3A%5C%227454287947%5C%22%2C%5C%22idRef%5C%22%3A%5C%221086441183%5C%22%7D%22%2C%7B%7D%5D%7D%2Cnull%2Cnull%2Ctrue%5D',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Content-Type': 'text/plain;charset=UTF-8',
    'Accept': 'text/x-component',
    'Next-Action': '12fd83780d97281c2b5217bb8f7f5bb4af437906',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://app.tomcoin.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://app.tomcoin.app/?idUser=7454287947&idRef=1086441183',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 params = {
    'idUser': '7454287947',
    'idRef': '1086441183',
}
 proxies = {
    'http': 'http://127.0.0.:8080',
    'https': 'http://127.0.0.1:8080',
}
 data = '["7454287947","1086441183"]'

 response = requests.post('https://app.tomcoin.app/', params=params, cookies=cookies, headers=headers, data=data, verify=False)
# print(response.text)



 headers1 = {
    'Host': 'app.tomcoin.app',
    # 'Content-Length': '70',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://app.tomcoin.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://app.tomcoin.app/?idUser=7454287947&idRef=1086441183',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',

}

 json_data2 = {
    'data': {
        'userId': '7454287947',
        'clickPoints': 400,
        'passivePoints': 400,
    },
}
 json_data1 = {
    'userId': '7454287947',
    'claimType': [
        6,
    ],
    'claimablePoints': 1,
}
 response1 = requests.post('https://app.tomcoin.app/api/game/claim-reward', cookies=cookies, headers=headers1, json=json_data1, verify=False)
 response2 = requests.post('https://app.tomcoin.app/api/profile/save', cookies=cookies, headers=headers1, json=json_data2, verify=False)
 print("31",response1.text)
 print("31",response2.text)
 time.sleep(10)
