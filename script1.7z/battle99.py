import asyncio
import websockets
import json

async def send_message_with_battle_id():
    uri = "wss://api-clicker.pixelverse.xyz/socket.io/?EIO=4&transport=websocket"
    while True:
        try:
            async with websockets.connect(uri) as websocket:
                # Send the initial message to trigger the response containing battleId
                message = '40{"tg-id":6796696313,"secret":"b0ef47b233ca7a0c3112e657bac1b1ee38c83d9cb4d486112dcebb03710266e5","initData":"query_id=AAH5Wh0VAwAAAPlaHRWsms-n&user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1718088965&hash=b2c382d2a4fb2ed2f6eb5198e010e9f4813c4c069de48c786a5c185de1946733"}'
                await websocket.send(message)

                # Receive and parse the third response to extract battleId
                for _ in range(3):
                    response = await websocket.recv()
                try:
                    response_json = json.loads(response[response.index('['):])
                    battle_id = response_json[1]['battleId']
                    print("Extracted battleId:", battle_id)
                except (ValueError, KeyError):
                    print("Failed to extract battleId from response:", response)
                    return

                # Send messages infinitely with updated battleId
                while True:
                    updated_message = f'42["HIT",{{"battleId":"{battle_id}"}}]'
                    await websocket.send(updated_message)
                    #a = await websocket.recv()
                    #print("Sent updated message with battleId:", a)
                    await asyncio.sleep(0.09)  # Adjust the delay as needed

        except websockets.exceptions.ConnectionClosed:
            print("WebSocket connection closed. Reconnecting...")

asyncio.run(send_message_with_battle_id())











