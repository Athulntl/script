import requests

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...import requests
import time
while True:

   headers = {
    'Host': 'api.tapswap.ai',
    # 'Content-Length': '385',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'X-Cv': '632',
    'Cache-Id': 'W7tx3zPm',
    'Content-Type': 'application/json',
    'X-Touch': '1',
    'X-App': 'tapswap_server',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://app.tapswap.club',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://app.tapswap.club/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
    'Connection': 'keep-alive',
}

   json_data = {
    'init_data': 'query_id=AAHfxsFAAAAAAN_GwUBiK1C3&user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1719671444&hash=f5c0bfd1ec2bbfe27fef2065b9e7812f8b9f1dc528201b14ce2edc7a94330c1f',
    'referrer': '',
    'bot_key': 'app_bot_0',
    'chr': 110687,
}




   response = requests.post('https://api.tapswap.ai/api/account/login', headers=headers, json=json_data, verify=False)
   print(response.text)
   access=response.json()['access_token']

 

   headers1 = {
    'Host': 'api.tapswap.ai',
    # 'Content-Length': '31',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {access}',
    'X-Cv': '632',
    'Cache-Id': 'gID8GiD9',
    'Content-Type': 'application/json',
    'X-Touch': '1',
    'X-App': 'tapswap_server',
    'Content-Id': '1086393916',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://app.tapswap.club',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://app.tapswap.club/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
    'Connection': 'keep-alive',
}

   json_data1 = {
    'taps':100 ,
    'time': 1719592147645,
}


   response1 = requests.post('https://api.tapswap.ai/api/player/submit_taps', headers=headers1, json=json_data1, verify=False)
   print(response.text) 

