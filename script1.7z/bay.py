import requests,time,json
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

number=["77","31","79","99"]


csrf = ["e416e868dc06067d8bc108dac2a59249a21f0dbaf6659333c9b66dfaf43fb61b%7Ca829233b0a6af38be0bfb39c96281d4433c8920695d31d086c174ee3ef15086d", "b5c2a39d545d37f78031c4132312b2a823c979391d15c0de77191701250ebcf0%7Cc75c88e16180c2191a462ce75dbea4ad342257d5bd649d446f6111b47f497336", "c9d57155a52cf94632279551e27536befd236e8774813c7b5ae8375897b7bd42%7C83b80b61b9f29befff1d3b13113750859ddf61c14392ae1b1db312527b5e1a1d","b9fb2f2004e72cc3e85524447f80b518b2e623a375bee2aaac4fd8e2673815c9%7Cc2548736fbb162ebe81a8f8435f3c8d8ea0f8aaf78d266e13ed7ecce23da1b85"]

callback = ["https%3A%2F%2Frecent-deals.vercel.app%2F%23tgWebAppData%3Duser%253D%25257B%252522id%252522%25253A1086441183%25252C%252522first_name%252522%25253A%252522Athul%252522%25252C%252522last_name%252522%25253A%252522G%252522%25252C%252522username%252522%25253A%252522Aaathulll%252522%25252C%252522language_code%252522%25253A%252522en%252522%25252C%252522allows_write_to_pm%252522%25253Atrue%25257D%2526chat_instance%253D9148271279819295074%2526chat_type%253Dsender%2526auth_date%253D1719240221%2526hash%253Def5e13a376081bec0727e61b43d6d1f7d2314b328add50f8539c6f2d2ac20437%26tgWebAppVersion%3D7.4%26tgWebAppPlatform%3Dandroid%26tgWebAppThemeParams%3D%257B%2522bg_color%2522%253A%2522%2523ffffff%2522%252C%2522section_bg_color%2522%253A%2522%2523ffffff%2522%252C%2522secondary_bg_color%2522%253A%2522%2523f0f0f0%2522%252C%2522text_color%2522%253A%2522%2523222222%2522%252C%2522hint_color%2522%253A%2522%2523a8a8a8%2522%252C%2522link_color%2522%253A%2522%25232678b6%2522%252C%2522button_color%2522%253A%2522%252350a8eb%2522%252C%2522button_text_color%2522%253A%2522%2523ffffff%2522%252C%2522header_bg_color%2522%253A%2522%2523527da3%2522%252C%2522accent_text_color%2522%253A%2522%25231c93e3%2522%252C%2522section_header_text_color%2522%253A%2522%25233a95d5%2522%252C%2522subtitle_text_color%2522%253A%2522%252382868a%2522%252C%2522destructive_text_color%2522%253A%2522%2523cc2929%2522%257D", "https%3A%2F%2Frecent-deals.vercel.app%2F%3FtgWebAppStartParam%3Dinvite-40c1c6df%23tgWebAppData%3Duser%253D%25257B%252522id%252522%25253A7454287947%25252C%252522first_name%252522%25253A%252522cryptoboy%252522%25252C%252522last_name%252522%25253A%252522%252522%25252C%252522username%252522%25253A%252522cryptoooboy%252522%25252C%252522language_code%252522%25253A%252522en%252522%25252C%252522allows_write_to_pm%252522%25253Atrue%25257D%2526chat_instance%253D712902773243751970%2526chat_type%253Dprivate%2526start_param%253Dinvite-40c1c6df%2526auth_date%253D1719244946%2526hash%253D260e000320d4f080b528a7e290dad049994a52bef1aa5cc5f303a15bc9d91bbc%26tgWebAppVersion%3D7.4%26tgWebAppPlatform%3Dandroid%26tgWebAppThemeParams%3D%257B%2522bg_color%2522%253A%2522%2523ffffff%2522%252C%2522section_bg_color%2522%253A%2522%2523ffffff%2522%252C%2522secondary_bg_color%2522%253A%2522%2523f0f0f0%2522%252C%2522text_color%2522%253A%2522%2523222222%2522%252C%2522hint_color%2522%253A%2522%2523a8a8a8%2522%252C%2522link_color%2522%253A%2522%25232678b6%2522%252C%2522button_color%2522%253A%2522%252350a8eb%2522%252C%2522button_text_color%2522%253A%2522%2523ffffff%2522%252C%2522header_bg_color%2522%253A%2522%2523527da3%2522%252C%2522accent_text_color%2522%253A%2522%25231c93e3%2522%252C%2522section_header_text_color%2522%253A%2522%25233a95d5%2522%252C%2522subtitle_text_color%2522%253A%2522%252382868a%2522%252C%2522destructive_text_color%2522%253A%2522%2523cc2929%2522%257D", "https%3A%2F%2Frecent-deals.vercel.app%2F%3FtgWebAppStartParam%3Dinvite-40c1c6df%23tgWebAppData%3Duser%253D%25257B%252522id%252522%25253A6737423619%25252C%252522first_name%252522%25253A%252522Swa%252522%25252C%252522last_name%252522%25253A%252522Am%252522%25252C%252522username%252522%25253A%252522imSaraswathy%252522%25252C%252522language_code%252522%25253A%252522en%252522%25252C%252522allows_write_to_pm%252522%25253Atrue%25257D%2526chat_instance%253D9102594542694241383%2526chat_type%253Dprivate%2526start_param%253Dinvite-40c1c6df%2526auth_date%253D1719245425%2526hash%253D94a7c7d07b0cb52a8a84eecb0fbc219944b2f90e89afc45a62a6b045affa6d7f%26tgWebAppVersion%3D7.2%26tgWebAppPlatform%3Dandroid%26tgWebAppThemeParams%3D%257B%2522bg_color%2522%253A%2522%2523ffffff%2522%252C%2522section_bg_color%2522%253A%2522%2523ffffff%2522%252C%2522secondary_bg_color%2522%253A%2522%2523f0f0f0%2522%252C%2522text_color%2522%253A%2522%2523222222%2522%252C%2522hint_color%2522%253A%2522%2523a8a8a8%2522%252C%2522link_color%2522%253A%2522%25232678b6%2522%252C%2522button_color%2522%253A%2522%252350a8eb%2522%252C%2522button_text_color%2522%253A%2522%2523ffffff%2522%252C%2522header_bg_color%2522%253A%2522%2523527da3%2522%252C%2522accent_text_color%2522%253A%2522%25231c93e3%2522%252C%2522section_header_text_color%2522%253A%2522%25233a95d5%2522%252C%2522subtitle_text_color%2522%253A%2522%252382868a%2522%252C%2522destructive_text_color%2522%253A%2522%2523cc2929%2522%257D","https%3A%2F%2Frecent-deals.vercel.app%2F%3FtgWebAppStartParam%3Dinvite-40c1c6df%23tgWebAppData%3Duser%253D%25257B%252522id%252522%25253A6796696313%25252C%252522first_name%252522%25253A%252522Akkku%252522%25252C%252522last_name%252522%25253A%252522A%252522%25252C%252522username%252522%25253A%252522adkdmdf%252522%25252C%252522language_code%252522%25253A%252522en%252522%25252C%252522allows_write_to_pm%252522%25253Atrue%25257D%2526chat_instance%253D-2657541688088493849%2526chat_type%253Dprivate%2526start_param%253Dinvite-40c1c6df%2526auth_date%253D1719245584%2526hash%253D1f4253b79a737fbc7242b1d99051d554f680c97e784e7aa69a8a7b2cc4c475ab%26tgWebAppVersion%3D7.2%26tgWebAppPlatform%3Dandroid%26tgWebAppThemeParams%3D%257B%2522bg_color%2522%253A%2522%2523ffffff%2522%252C%2522section_bg_color%2522%253A%2522%2523ffffff%2522%252C%2522secondary_bg_color%2522%253A%2522%2523f0f0f0%2522%252C%2522text_color%2522%253A%2522%2523222222%2522%252C%2522hint_color%2522%253A%2522%2523a8a8a8%2522%252C%2522link_color%2522%253A%2522%25232678b6%2522%252C%2522button_color%2522%253A%2522%252350a8eb%2522%252C%2522button_text_color%2522%253A%2522%2523ffffff%2522%252C%2522header_bg_color%2522%253A%2522%2523527da3%2522%252C%2522accent_text_color%2522%253A%2522%25231c93e3%2522%252C%2522section_header_text_color%2522%253A%2522%25233a95d5%2522%252C%2522subtitle_text_color%2522%253A%2522%252382868a%2522%252C%2522destructive_text_color%2522%253A%2522%2523cc2929%2522%257D"]

session = ["eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..zSqcYoliXDp4xHuu.fEoO3XhVoU1vTSqVhEbQi2bXSGpxI5COQxZiFyaU8aWLelz9AMX3K30IHsrGRLhC73ucnW8eJkY1JyVtOMTTZz65tmy3_TJjOo3guGQBP6na3krG-iKYCx5zPkaZFoy9tzSczr3-fSInAoGVhAZ2M7Jk0pGOFg.bnSPgFm9Tl9sojYr_tasJw", "eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..vjfW5AuIEyP0_9e8.KNWpkhgoFb9DG5BTKoejiTJunVnGg8BE1idc5bltHH842ubXvcyCbZs0hNhxlObhIMUMPLSUxNb36aoJ6-maYgEGVMn0ER6igjUjLWkMqeVuhYphItj3vv4Ka1tc_MdUsIdImQ3un6CxMNGp1gX5K_jLXLiVfn3G.LKaeQ79j6udcfHhgdEVqUQ", "eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..7IfN65ua_2Ey0Uw-.UhII4KxGxZYIGsTE3fJJ-2JEMYfbYe4bo4i7FfJaRhDMyTEkyS0-dRl8tbi-s1o0ihy3qvHLo07KarVNimARu93y4th23cwFdeiUXppMMZd8hLDIDxqnGYv2QkVA-VvXePz5pIE-nKlebdVG4VHdXFn9eT0BZMJCYA.TKHYfJTnk4R20t9WrEb05A","eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..f9tnYS72obERm2I6.wUww7kDSfNYpxy30dBqsGylNYOnvRHe0EAkOugJmzG6bCVnMykOtzJhRqxL8LVSzv66zaroxCB7RLqAmoZunWE1vtd1Xrz5GSL7_JJdujahf1fNgttznRDrCTzEC16j22cG_eZib9gl7RwWASWT6SQpyKbY.xqD7DgDouh72_093NiQubg"]
while True:

 for a, b, c, n in zip(csrf, callback, session,number):
    cookies = {
        '__Host-next-auth.csrf-token': a,
        '__Secure-next-auth.callback-url': b,
        '__Secure-next-auth.session-token': c,
    }

    headers = {
        'Host': 'recent-deals.vercel.app',
        'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
        'Sec-Ch-Ua-Platform': '"Android"',
        'Sec-Ch-Ua-Mobile': '?1',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'Origin': 'https://recent-deals.vercel.app',
        'X-Requested-With': 'org.telegram.messenger',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://recent-deals.vercel.app/',
        'Accept-Language': 'en,en-US;q=0.9',
        'Priority': 'u=1, i',
    }

    # Define the parameters for the request
    params = {
        'batch': '1',
    }
    params1 = {
    'batch': '1',
    'input': '{"0":{"json":null,"meta":{"values":["undefined"]}}}',
}

    # Define the JSON data for the request
    json_data = {
        '0': {
            'json':25 ,
        },
    }

    json_data1 = {
    '0': {
        'json': None,
        'meta': {
            'values': [
                'undefined',
            ],
        },
    },
}
    
    json_dataa = {
    '0': {
        'json': {
            'clickTimes': 40,
            'taskObj': {
                'TASK_FARM_ONE_TIME': 40,
                'TASK_FARM_TWO_TIME': 0,
                'TASK_INVITE_ONE_USER': 0,
                'TASK_INVITE_TWO_USER': 0,
                'TASK_SOCIAL': 0,
                'TASK_INVITE_SOCIAL': 0,
                'TASK_CHECK_IN': 0,
            },
        },
    },
}
    json_datab = {
    '0': {
        'json': {
            'clickTimes': 40,
            'taskObj': {
                'TASK_FARM_ONE_TIME': 40,
                'TASK_FARM_TWO_TIME': 40,
                'TASK_INVITE_ONE_USER': 0,
                'TASK_INVITE_TWO_USER': 0,
                'TASK_SOCIAL': 0,
                'TASK_INVITE_SOCIAL': 0,
                'TASK_CHECK_IN': 0,
            },
        },
    },
}
    json_datac = {
    '0': {
        'json': {
            'clickTimes': 40,
            'taskObj': {
                'TASK_FARM_ONE_TIME': 40,
                'TASK_FARM_TWO_TIME': 40,
                'TASK_INVITE_ONE_USER': 40,
                'TASK_INVITE_TWO_USER': 0,
                'TASK_SOCIAL': 0,
                'TASK_INVITE_SOCIAL': 0,
                'TASK_CHECK_IN': 0,
            },
        },
    },
}
    json_datad = {
    '0': {
        'json': {
            'clickTimes': 40,
            'taskObj': {
                'TASK_FARM_ONE_TIME': 40,
                'TASK_FARM_TWO_TIME': 40,
                'TASK_INVITE_ONE_USER': 40,
                'TASK_INVITE_TWO_USER': 40,
                'TASK_SOCIAL': 0,
                'TASK_INVITE_SOCIAL': 0,
                'TASK_CHECK_IN': 0,
            },
        },
    },
}
    json_datae = {
    '0': {
        'json': {
            'clickTimes': 40,
            'taskObj': {
                'TASK_FARM_ONE_TIME': 40,
                'TASK_FARM_TWO_TIME': 40,
                'TASK_INVITE_ONE_USER': 40,
                'TASK_INVITE_TWO_USER': 40,
                'TASK_SOCIAL': 40,
                'TASK_INVITE_SOCIAL': 0,
                'TASK_CHECK_IN': 0,
            },
        },
    },
}
    json_dataf = {
    '0': {
        'json': {
            'clickTimes': 40,
            'taskObj': {
                'TASK_FARM_ONE_TIME': 40,
                'TASK_FARM_TWO_TIME': 40,
                'TASK_INVITE_ONE_USER': 40,
                'TASK_INVITE_TWO_USER': 40,
                'TASK_SOCIAL': 40,
                'TASK_INVITE_SOCIAL': 40,
                'TASK_CHECK_IN': 0,
            },
        },
    },
}
    json_datag = {
    '0': {
        'json': {
            'clickTimes': 40,
            'taskObj': {
                'TASK_FARM_ONE_TIME': 40,
                'TASK_FARM_TWO_TIME': 40,
                'TASK_INVITE_ONE_USER': 40,
                'TASK_INVITE_TWO_USER': 40,
                'TASK_SOCIAL': 40,
                'TASK_INVITE_SOCIAL': 40,
                'TASK_CHECK_IN': 40,
            },
        },
    },
}
  

    # Make the POST request
    responsea = requests.post(
        'https://recent-deals.vercel.app/api/trpc/tapGame.syncTap',
        params=params,
        cookies=cookies,
        headers=headers,
        json=json_dataa,
        verify=False,
    )
    print(n,"task 1")
    time.sleep(410)
    responseb = requests.post(
        'https://recent-deals.vercel.app/api/trpc/tapGame.syncTap',
        params=params,
        cookies=cookies,
        headers=headers,
        json=json_datab,
        verify=False,
    )
    print(n,"task 2")
    time.sleep(410)
    responsec = requests.post(
        'https://recent-deals.vercel.app/api/trpc/tapGame.syncTap',
        params=params,
        cookies=cookies,
        headers=headers,
        json=json_datac,
        verify=False,
    )
    print(n,"task 3")
    time.sleep(410)
    responsed = requests.post(
        'https://recent-deals.vercel.app/api/trpc/tapGame.syncTap',
        params=params,
        cookies=cookies,
        headers=headers,
        json=json_datad,
        verify=False,
    )
    print(n,"task 4")
    time.sleep(410)
    responsee = requests.post(
        'https://recent-deals.vercel.app/api/trpc/tapGame.syncTap',
        params=params,
        cookies=cookies,
        headers=headers,
        json=json_datae,
        verify=False,
    )
    print(n,"task 5")
    time.sleep(410)
    responsee = requests.post(
        'https://recent-deals.vercel.app/api/trpc/tapGame.syncTap',
        params=params,
        cookies=cookies,
        headers=headers,
        json=json_dataf,
        verify=False,
    )
    print(n,"task 6")
    time.sleep(410)
    responsee = requests.post(
        'https://recent-deals.vercel.app/api/trpc/tapGame.syncTap',
        params=params,
        cookies=cookies,
        headers=headers,
        json=json_datag,
        verify=False,
    )
    print(n,"task 7")
    response1 = requests.post(
        'https://recent-deals.vercel.app/api/trpc/userExp.harvestFarm',
        params=params,
        cookies=cookies,
        headers=headers,
        json=json_data1,
        verify=False,
    )
    response2 = requests.post(
        'https://recent-deals.vercel.app/api/trpc/userExp.startFarm',
        params=params,
        cookies=cookies,
        headers=headers,
        json=json_data1,
        verify=False,
    ) 
    response = requests.get(
    'https://recent-deals.vercel.app/api/trpc/userExp.getUserExp',
    params=params1,
    cookies=cookies,
    headers=headers,
    verify=False,
)
    print(response.text)
    print(n,"balance",json.loads(response.text)[0]['result']['data']['json'])
        


 print("sleeping for 1.38 hr")
 time.sleep(6300)
