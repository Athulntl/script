import time
import requests
while True:


 cookies = {
    'ApplicationGatewayAffinityCORS': '6fbb6367aee5d18985d012e00f5955b5',
    'ApplicationGatewayAffinity': '6fbb6367aee5d18985d012e00f5955b5',
}

 headers = {
    'Host': 'celiav222apicomeback-csd3drc4awfxerbs.z01.azurefd.net',
    'Accept-Language': 'en-US,en;q=0.5',
    'Content-Type': 'application/json',
    'X-App-Identifier': '{"ct":"2LyIq9bUKWLeI7Fk8qvO3GByQU5xq7JZFZs/r8LFkr6qPyguTQYI8rwa1JSaGfJhy6uoYsjn8WstqyayY4YwSFrDIo5NiTMcEVuLFq7SDlkyJCe2tCVTowVxpVCPibfmU3sO85UHXVzpDW0qpJBkCGsVu2Oj+iUEhfcp0w3uXZ0dPtPG4Iur33dWZT927CFTBX21WDvNmoSnuwPbe7d/XoLoMD5lpR/gH9J3y2ICiKYT5Rp10tRNP30AnZLbg7TeLkPpNk6I0JES2uQukF0/aJF6cplRBEUBBMoM/lxqT7bhPJ4dkSsFj/yDNX6ylZtrNKr4YQ88khpIF40flpie7NISXW3MEmORTPw6/bx6PSY52hwiuYyxf5ZwLu47iIxLP+RbNit+zzTz0r5z3UblJldyloi2qDFTVb0QJfetegp4NwBRvb3VyEfRJTFb50O7uk6LtnSRJPJ4pZd91d6FvBbKBO/9mbXHH44+GFK4C6q4a1FbPiloE1fsiXXYy5I0l3eJpNtx76VVpjS1S6zbGnj3aZ2zuPL2BMvIxCzXw6cFRWGwTN2SXIsT/xsU2uI74bAZrwfFrZpLq0A3eN2rvrqUq4sOiRmG9H6QAsCIfgI1LfrUByzsciEvv+LRXUd//fCJQXkcmmCQp3L3MOq0ygLAndLbe53hxIgldziJJm1nxPF4Zd8MGoopLFWdcpR12DxxUVfh/X/BUb0FtnbEHyKMEkL1LJp0ihKDnBLTF/XWpQFIfwGpv1LKFdqi9F3/GU4wwVKj1LmqfCkZl6hAfHfncLL8wJZklskzVd6mulknAhAGRs5QYys1qCnG1cEOGaGZwLcuzwkauhEBquwoV43H/R4RfjQpHcoB+J+EqCFiAniuktRxJYkt9NxT8ywCx5Yr9SNeQM7EF90qy95yJFzU9khZ0ohIIvB3SpRfZkdl9JdxArxLgmPBonH1NQJIlVM+FC6ti5jrAZWAWojG5S++x5wWRpjRvu8Lyy6K0COFJnZAz/Vrk89oxH+fHk//U/tEX1nYggSB7d8ScmgVRFtnzyd3Nnyqq5LNr0NWLbf0wTbRNAw+K4fhLz7u0RLg872b+YwG0EeYz8KHWRJCSrhzSP1fKYYrOtfv4LQwUqgv+xLPUUFdazxp70B9Gc3nQvSYWWjPIv73YzYKp18RCoF3wkLdOio9IibTkNIyoKnptbEWIDFMW42Rc/HnTbEEL+XJrgYEDRI+HdZzPC0s+nz9cP0B/9JFKiw5Rae+9nHa1OhV18itWSEOo4qmi7nwEQQlTZuc7n7qMFtXHx4WJw0jSKrUvz/gkXBvnzdI9zDyjuRFQ+RAb/Uxk1bu3Ex/w2wbTLjGpVojusvnlGDJA3hh4ZHq64pXxMh92poLz2ok41ArmkTP2iyyl4eDNDwxnwgM6BdOTCsTqXm8PcqI3K4uVn9XOm0NRdufCEIbR3gXDAUWbR4whZqVsRKjFlecuhIykLkxu+qhPDI0tjRe9Oobe9Rf37KSod9f+6R85MenS+yLNpxicAHFi8Ow0cSGJytboGcI6tft9rYLfkIMD6oaV1hQu1lNSGcY/IxmbHJV9KOSVOiS0h5SH6viOoFst9OfWn0swf4eE5BaRxyFC0OTOaR7PBp6XY6nT7vsEXshDjjaO+HvvseLgMSiwbWgjmWcR6EXkchOzwHeUJHlMMH/a66njtaXM2C7XgXh1CEb8iMEMCWQ39XDmAOAo5tAet5ycWrI/5G8oSYahmEVz8p+ZqB/FID1GXokqViOlKkwfmTxfOSgvZsijefvVtpi7Qxf/jYSQHI98aUELK6vlAhC6MVZFyaLeFCNKDdNr+DZwwqPc6pi3p3aJloHg0uz3uBuQ0M8tdD4UFd53iUl6R/yDOlchmbGtJEdhM5nHH7jKWMj6KJlLnJ6T9H6EqzZoC6tvYtxlKUVbfPNQgfP+Pe5RMZ6Ul7duaJC++Jh4PGxm49oiSCHSOFdqHA1IXCF3fMJDUmvd+pNlSWIfoG5FIrSTSqoaPWAlqnUnKv1JVcFF6ht4ZXlz9C9VdnJErMLtjCEBYmYdB/m7xBwBlHTZLXTOjQKRS439aaj7MY3w1SG0RJDfT0JobfWpyWsdRpPcLSrjUZVVFtc954MKRU57yVuw/ZNquwGt0+hAROr1gOnQmdtJpi3D7FFfNXZxx4AC7ZOFVrN6NY/wuEt07nzwK4QoSPwnLg41aPUGkDH4bE+VarfasPIkOMas8IMCrlO7ND4Vflmaw4jJ6QhI3Hf9HQEXrZ5RJP8vmA/RYL4OFSrUBp6B8og9e/LmKOOemfa3hnxW64+XK7OTWvnyMZqdKErBW/No0TVIRYDdJxs61zwv5i92MeU9/LNfzc39yJ/Ir9rpIjTd8H+aepwdAex5eLEeDIvEejilRLmp1fDFTTW2t0CSJgdzZor8hJ/Q+9gFGuXACnjQFiMwpjS26MXCgdTbno2gmwWRRpNALYStgYCCiouu0+xUjThhkvTn39pDOprdsyj8phIgKIeL9aEu3l+FWsNFpdq8PZv77/gLho2xF+xXa6tN6wNwLeli3TJMQz/YayV+KTjlh845AWke/dkSfAPgpSNXZqf/A+6zNFF0Kgb2cBPdCOzlK5CslK+rQ3OEVc+le731KQGk0rl8/QtFy1NdAOdndLZSXe+l6M/O/IhTpzuibz2L1GWZmZuEGBY8+ZRVKdgdIdVUGWCgulbByO5/23yU+58n/FXDYR4KZsfPJukgi74DHbOR/Eo","iv":"c55cf82598a1345e3e58d0ac264f5f32","s":"735aecd7cdb63ee7"}',
    'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2NlbGlhdm1jb25uZWN0LmNvbm5lY3RjZWxpYS5sb2wvYXBpL2F1dGgvbG9naW4iLCJpYXQiOjE3MTU4NjMzMTgsImV4cCI6MTgzNjgyMzMxOCwibmJmIjoxNzE1ODYzMzE4LCJqdGkiOiJKR3FDMjVSOFVJcjNmZVBjIiwic3ViIjoiMTk1MyIsInBydiI6IjIzYmQ1Yzg5NDlmNjAwYWRiMzllNzAxYzQwMDg3MmRiN2E1OTc2ZjcifQ.ytHAq-2evgkEf-Vebit-z8T-Pz7i0jhVfBapwJJtBq4',
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; ASUS_I005DA Build/PI)',
    # 'Accept-Encoding': 'gzip, deflate, br',
    # 'Content-Length': '96',
    # 'Cookie': 'ApplicationGatewayAffinityCORS=6fbb6367aee5d18985d012e00f5955b5; ApplicationGatewayAffinity=6fbb6367aee5d18985d012e00f5955b5',
}

 json_data = {
    'ct': 'MabZ4QyBTJzs591SY8/ncQ==',
    'iv': 'b0e9e3c7dfde26cf0251835f488a7c3f',
    's': '77ebc192b430141c',
}

 response = requests.put(
    'https://celiav222apicomeback-csd3drc4awfxerbs.z01.azurefd.net/api/user/minequarterdaily',
    cookies=cookies,
    headers=headers,
    json=json_data,
    verify=False,
)

 print(response.text)
 time.sleep(21600)
