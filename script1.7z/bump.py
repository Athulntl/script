import requests
import requests,time
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
list=["$2y$12$FOlHWhonW6fqOzg/Z0FDVu8CdVlAqt3/BZIYQvFgCqZ3Ld9wBsfmW","$2y$12$G.F2hJUVFKd1v/vDQl5C0uqITbxzrSWyMGw4PF2UFMFmpDeppUMlm"]
while True:
 for i in list:
  headers = {
    'Host': 'api.mmbump.pro',
    # 'Content-Length': '23',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': i,
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://mmbump.pro',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://mmbump.pro/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

  json_data = {
    'status': 'inProgress',
}

  response = requests.post('https://api.mmbump.pro/v1/farming/start', headers=headers, json=json_data, verify=False)
  
  time.sleep(5)
  headers1 = {
    'Host': 'api.mmbump.pro',
    # 'Content-Length': '19',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': i,
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://mmbump.pro',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://mmbump.pro/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

  json_data1 = {
    'tapCount': 200,
}

  response1 = requests.post('https://api.mmbump.pro/v1/farming/finish', headers=headers1, json=json_data1, verify=False)
  print("balance",response1.json()['balance'],"taps ",response1.json()['session']['taps'],response1.json()['session']['user_telegram_id'])
