import asyncio
import websockets

async def send_message():
    uri = "wss://api-tma.locago.tech/socket.io/?EIO=4&transport=websocket"

    initial_message = '40{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOnsidXVpZCI6ImMxNGU0ODcxLTJjODctNGJiZi1hNTY2LWQ2MjBhZjRmZDY4NiIsInJlZmVycmVkSWRzIjpbIjEiLCIzMSIsIjcxIiwiMjAyIiwiMzM4NSIsIjE0Njk2IiwiMTQ4OTgiLCIxNTI4NyJdfSwiaWF0IjoxNzIwMDk4ODkyLCJleHAiOjE3NTE2NTY0OTJ9.B2eF5LfP3nEHl6v_IgJv5eNib2legADArp1nlP8VKiA","uuid":"c14e4871-2c87-4bbf-a566-d620af4fd686"}'
    repeating_message = '42["tapping",{"locationId":1654645,"tap":5,"lat":31.24916,"lng":121.48789833333333}]'

    try:
        async with websockets.connect(uri) as websocket:
            # Send the initial message
            await websocket.send(initial_message)
            initial_response = await websocket.recv()
            print(f"Initial response: {initial_response}")
            
            # Enter infinite loop to send the repeating message
            while True:
                await websocket.send(repeating_message)
                response = await websocket.recv()
                print("31",response)
                await asyncio.sleep(1)  # Optional: add a delay between messages
    except websockets.exceptions.InvalidStatusCode as e:
        print(f"Connection failed with status code: {e.status_code}")
        print("Response headers:", e.headers)
    except Exception as e:
        print(f"An error occurred: {e}")

asyncio.run(send_message())
