import requests
import time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
while True:


# Initial cookies and headers
 cookies = {
    '_ga': 'GA1.1.34506714.1719837480',
    '_ga_TDW94HCJN6': 'GS1.1.1720408196.5.0.1720408196.60.1.403243057',
    'refresh_token': 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjUxNTczMDQ3In0.eyJ0ZWxlZ3JhbUlkIjoiNzQ1NDI4Nzk0NyIsImlhdCI6MTcyMDQwODE5NywiZXhwIjoxNzIwNDk0NTk3LCJpc3MiOiJ0b25zdGF0aW9uIn0.ivNb8eqhAQfj-CXboFZ9lmc1grnc3hb89P8JWNQH78HG8JEU0YCf82xlYNOwwiPKn4-w9WQJX7aNMsqr3i83QADwecwiyhPe0SXugO3V5viUgyrTdzms1f5ocfH7m4z9XjKfCvxMsqKJfIiDB65V0Mra9J7LYHTso68OaoIy_g8aNjamSEiG-yybHptSMCWBpzA-v6QCsno51L4ONz9RcHveTzgqRy2_5eAXF4CJBUCM6HX1ldyIgzSi_myOtid9jUvWHEoWi7Acl3hHzNWFeYmrLyUK8Qj8fJJpbCWV4-M8vPG8UhhirXQD1h9OXEGs5fllPygBPbtkJKbLiZFIDHMumfaQVhfP_rnpMFJXRdwNK4xSlTOgpaKWlGXzPowazh9zUltIdyjZ4_p-yd5RTVGSoe3sATFV1k8iot6cDFkwuCjKJ9bEH8g7Bjcqs8Fyg36nrJJeYm2gn3o1UTCAkoTlKqbpl9Xpk8mLjAumafXcc3boosthPjLawJ_lcnseg8728w27uOdG58riY6TFox08datpub643oPvGkYOkb9T3fHsxPEeknIxvoSrOAv5r9_eMeDnqcpqUcrPAHgP-b50puKlriEFobneo4RARH52kJAoqWlEmzxS1NR-Jg726U_E44kUZxBWeX8fcFahsMGHfp5BMh1SH3Tvgs8WT8M',
}
 headers = {
    'Host': 'tonstation.app',
    # 'Content-Length': '270',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://tonstation.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tonstation.app/app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = {
    'user': {
        'id': 7454287947,
        'first_name': 'cryptoboy',
        'last_name': '',
        'username': 'cryptoooboy',
        'language_code': 'en',
        'allows_write_to_pm': True,
    },
    'chat_instance': '-2620670898600252999',
    'chat_type': 'sender',
    'auth_date': '1720408194',
    'hash': '4c6875224dbd93aa10598fb34b4e89a58e41445495d3628b599f70abf570a251',
}
 response = requests.post(
    'https://tonstation.app/userprofile/api/v1/users/auth',
    cookies=cookies,
    headers=headers,
    json=json_data,
    verify=False,
)
# print(response.text)
 a = response.json()['accessToken']
 r = response.json()['refreshToken']

# New cookies and headers with updated tokens
 cookies1 = {
    '_ga': 'GA1.1.34506714.1719837480',
    'accessToken': a,
    'refresh_token': r,
    '_ga_TDW94HCJN6': 'GS1.1.1720408196.5.0.1720408196.60.1.403243057',
}
 headers1 = {
    'Host': 'tonstation.app',
    # 'Content-Length': '59',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {a}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://tonstation.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tonstation.app/app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data1 = {
    'userId': '7454287947',
    'taskId': '1',
}

 response1 = requests.post('https://tonstation.app/farming/api/v1/farming/start', cookies=cookies1, headers=headers1, json=json_data1, verify=False)
 print("31", response1.text)
 idd = response1.json()['data']['_id']
 print("31", idd)
 json_data2 = {
    'userId': '7454287947',
    'taskId': idd,
}
 print("31 started", idd)
 print("sleep for 8 hr")
 time.sleep(28810)

 while True:
    json_data = {
    'user': {
        'id': 7454287947,
        'first_name': 'cryptoboy',
        'last_name': '',
        'username': 'cryptoooboy',
        'language_code': 'en',
        'allows_write_to_pm': True,
    },
    'chat_instance': '-2620670898600252999',
    'chat_type': 'sender',
    'auth_date': '1720408194',
    'hash': '4c6875224dbd93aa10598fb34b4e89a58e41445495d3628b599f70abf570a251',
}
    response = requests.post(
    'https://tonstation.app/userprofile/api/v1/users/auth',
    cookies=cookies,
    headers=headers,
    json=json_data,
    verify=False,
)
    a = response.json()['accessToken']
    r = response.json()['refreshToken']

# New cookies and headers with updated tokens
    cookies2 = {
    '_ga': 'GA1.1.34506714.1719837480',
    'accessToken': a,
    'refresh_token': r,
    '_ga_TDW94HCJN6': 'GS1.1.1720408196.5.0.1720408196.60.1.403243057',
}
    headers2 = {
    'Host': 'tonstation.app',
    # 'Content-Length': '59',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {a}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://tonstation.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tonstation.app/app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}
    
    response2 = requests.post('https://tonstation.app/farming/api/v1/farming/claim', cookies=cookies2, headers=headers2, json=json_data2, verify=False)
    if response2.status_code == 200:
        print("31 claimed", idd)
        print(response2.text)
        break
    else:
        print("Retrying...")
        time.sleep(5)
