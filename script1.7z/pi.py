import requests,time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
while True:

 headers = {
    'Host': 'tpib-api.pibridge.org',
    # 'Content-Length': '33',
    'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Microsoft Edge";v="126", "Microsoft Edge WebView2";v="126"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NjgwMmFiN2NkNmNmNGVhM2U0OTliMDMiLCJzZXNzaW9uSWQiOiJjMzEzMDQwZC1lNmY3LTQ0YzItYjc5ZS1lMmJmOTcwODdkMDAiLCJpYXQiOjE3MTk2NzczNjgsImV4cCI6MTcyMDU0MTM2OH0.IMuP5CExwyZvj_KBhvMNfyQ7-LhvKm9YkI8zA9GX8iE',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0',
    'Content-Type': 'application/json',
    'Accept': 'application/json, text/plain, */*',
    'Authorizationtma': 'tma query_id=AAHfxsFAAAAAAN_GwUCEDm4n&user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1719676804&hash=69153c4bfe503e43bb5c64fd96df9a116f001a29911d3c18c7c6964f90b48c6b',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Origin': 'https://main.dzngeifcxpk69.amplifyapp.com',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://main.dzngeifcxpk69.amplifyapp.com/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = {
    'numberOfTap': 100,
    'durationTap': 2,
}

 response = requests.post('https://tpib-api.pibridge.org/v1/users/tap', headers=headers, json=json_data, verify=False)
 print(response.text)
 time.sleep(10)

