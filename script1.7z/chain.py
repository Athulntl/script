import subprocess
import time

def run_programs():
    processes = []
    # Replace 'program_to_run_1.py', 'program_to_run_2.py', and 'program_to_run_3.py'
    # with the names of your Python programs
    for program in ['chain77.py','chain79.py','chain99.py','chain31.py']:
        process = subprocess.Popen(['python', program])
        processes.append(process)
    return processes

def kill_programs(processes):
    for process in processes:
        process.terminate()
        try:
            process.wait(timeout=1)
        except subprocess.TimeoutExpired:
            process.kill()

def main():
    while True:
        # Run the programs
        processes = run_programs()
        
        # Wait for some time (e.g., 10 seconds)
        time.sleep(30)
        # Kill the programs
        kill_programs(processes)
        print("killed")
if __name__== "__main__":
    main()








