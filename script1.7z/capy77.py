import requests
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...



while True :

 headers = {
    'Host': 'clicker.prod-api.tgquest.com',
    # 'Content-Length': '15',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': 'dXNlcj0lN0IlMjJpZCUyMiUzQTEwODY0NDExODMlMkMlMjJmaXJzdF9uYW1lJTIyJTNBJTIyQXRodWwlMjIlMkMlMjJsYXN0X25hbWUlMjIlM0ElMjJHJTIyJTJDJTIydXNlcm5hbWUlMjIlM0ElMjJBYWF0aHVsbGwlMjIlMkMlMjJsYW5ndWFnZV9jb2RlJTIyJTNBJTIyZW4lMjIlMkMlMjJhbGxvd3Nfd3JpdGVfdG9fcG0lMjIlM0F0cnVlJTdEJmNoYXRfaW5zdGFuY2U9LTkwODA1NDUxOTgwODU4ODg0NDgmY2hhdF90eXBlPXNlbmRlciZhdXRoX2RhdGU9MTcxNjEzMDU4MiZoYXNoPWRmOTRkZjUyYzBmMjc2ODViNjIwZjc4NTZmZTFkMjQwMTc2YzEzMTNiNGZmZDg1OWM4YWJkMTE1NjgzNTUzOGQ=',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.52 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://app.tgquest.com',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://app.tgquest.com/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = {
    'count': 15000,
}

 response = requests.post('https://clicker.prod-api.tgquest.com/clicker', headers=headers, json=json_data, verify=False)
 print('77',response.text) #json()['data']['points'])
# Note: json_data will not be serialized by requests
# exactly as it was in the original request.
#data = '{"count":15000}'
#response = requests.post('https://clicker.prod-api.tgquest.com/clicker', headers=headers, data=data, verify=False)
