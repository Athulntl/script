import requests
import time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
while True:


# Initial cookies and headers
 cookies = {
    '_ga': 'GA1.1.34506714.1719837480',
    'refresh_token': 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjUxNTczMDQ3In0.eyJ0ZWxlZ3JhbUlkIjoiNjc5NjY5NjMxMyIsImlhdCI6MTcyMDEwOTkxMywiZXhwIjoxNzIwMTk2MzEzLCJpc3MiOiJ0b25zdGF0aW9uIn0.HnRSUoKyh-OfY-LycK1kSyOsYfmm423VjDvpPuBAxnii9-Ltd9vYHBd_dO28BA45EzXZtmhamXA5Y_z27_lhM9QeM8X5BxwSmessVt0nKnXqFoPNe1dJK-LeS--mUFXN1ftjcupZj9-D29TDeqpP93HdY1LlRxD47SqLltP47dehoURmQDrClajAUNa7ydGOcLy9NN4IiPOxmNeAkNYJWuOGqtsaOwu7UvuqntzW4q_ZxN9fBVMfKW267eVI3UlhN1MXoFqlrirEhWwLUqjq4IHGrj-4Vl4JOverspdAwvp_xaZtZH5dTcaAhpJLdY_u52-d4NQo1q_zs7WMpzgrpITXqPov6V97K7vTmPHcX93fOQJKuikclpU4hfnkrcTvDaYzh1AEfbit0uq7g0HSL_fsaEqaEIYML0tMoiwSwVJrBa3mNAjzKvyWMqcNrkCgQIGUMNGe-S71UEuxustFxFhOpw5n9BywGy1GBG-wkEEfhcnsGxl-boidl4Ww_xAhNsRhBtrIEyYj-maFtZ_5ueSjNX_Qor4TDUOS7zMXQoHfgZUGg_xNNBPzTwWX7YbxwU7nLCw0IutswvfuRxC_JYHFDGzCMgchKR-DNUxtKOkyBBLExRtDVbPYPE_5HPodKPcEel998uitlTUZv_F4UvuPyG-ztiOU_heMpyQSPGk',
    '_ga_TDW94HCJN6': 'GS1.1.1720196043.2.0.1720196044.59.1.1278515934',
}
 headers = {
    'Host': 'tonstation.app',
    # 'Content-Length': '270',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://tonstation.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tonstation.app/app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = {
    'user': {
        'id': 6737423619,
        'first_name': 'Swa',
        'last_name': 'Am',
        'username': 'imSaraswathy',
        'language_code': 'en',
        'allows_write_to_pm': True,
    },
    'chat_instance': '854428827884825375',
    'chat_type': 'sender',
    'auth_date': '1720196046',
    'hash': '51453696a61d7ed78cbd3bf035ab7fb29a9cb201e0000781ad025f9af1095d8b',
}

 response = requests.post(
    'https://tonstation.app/userprofile/api/v1/users/auth',
    cookies=cookies,
    headers=headers,
    json=json_data,
    verify=False,
)
# print(response.text)
 a = response.json()['accessToken']
 r = response.json()['refreshToken']

# New cookies and headers with updated tokens
 cookies1 = {
    '_ga': 'GA1.1.34506714.1719837480',
    'accessToken': a,
    'refresh_token': r,
    '_ga_TDW94HCJN6': 'GS1.1.1720196043.2.0.1720196044.59.1.1278515934',
}
 headers1 = {
    'Host': 'tonstation.app',
    # 'Content-Length': '59',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {a}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://tonstation.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tonstation.app/app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data1 = {
    'userId': '6737423619',
    'taskId': '1',
}

 response1 = requests.post('https://tonstation.app/farming/api/v1/farming/start',   cookies=cookies1, headers=headers1, json=json_data1, verify=False)
 print("79", response1.text)
 idd = response1.json()['data']['_id']
 print("79", idd)
 json_data2 = {
    'userId': '6737423619',
    'taskId': idd,
}
 print("79 started", idd)
 print("sleep for 8 hr")
 time.sleep(28810)

 while True:
    json_data = {
    'user': {
        'id': 6737423619,
        'first_name': 'Swa',
        'last_name': 'Am',
        'username': 'imSaraswathy',
        'language_code': 'en',
        'allows_write_to_pm': True,
    },
    'chat_instance': '854428827884825375',
    'chat_type': 'sender',
    'auth_date': '1720196046',
    'hash': '51453696a61d7ed78cbd3bf035ab7fb29a9cb201e0000781ad025f9af1095d8b',
}

    response = requests.post(
    'https://tonstation.app/userprofile/api/v1/users/auth',
    cookies=cookies,
    headers=headers,
    json=json_data,
    verify=False,
)
    a = response.json()['accessToken']
    r = response.json()['refreshToken']

# New cookies and headers with updated tokens
    cookies2 = {
    '_ga': 'GA1.1.34506714.1719837480',
    'accessToken': a,
    'refresh_token': r,
    '_ga_TDW94HCJN6': 'GS1.1.1720196043.2.0.1720196044.59.1.1278515934',
}
    headers2 = {
    'Host': 'tonstation.app',
    # 'Content-Length': '59',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {a}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://tonstation.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tonstation.app/app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}
    
    response2 = requests.post('https://tonstation.app/farming/api/v1/farming/claim', cookies=cookies2, headers=headers2, json=json_data2, verify=False)
    if response2.status_code == 200:
        print("79 claimed", idd)
        print(response2.text)
        break
    else:
        print("Retrying...")
        time.sleep(5)
