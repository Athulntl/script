
import requests

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...

import time 
while True :
 time.sleep(20)
 headers = {
    'Host': 'api.tapswap.ai',
    # 'Content-Length': '372',
    'Sec-Ch-Ua': '"Chromium";v="124", "Android WebView";v="124", "Not-A.Brand";v="99"',
    'Content-Type': 'application/json',
    'X-App': 'tapswap_server',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.6367.161 Mobile Safari/537.36',
    'X-Cv': '1',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://app.tapswap.club',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://app.tapswap.club/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
    'Connection': 'close',
}

 json_data = {
    'init_data': 'query_id=AAHfxsFAAAAAAN_GwUC5Xdwm&user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1715567432&hash=7181334e82b6e4a33fbbf5f70938b44d051b3b3d63f1c7ec70fa1632a143db0d',
    'referrer': '',
    'bot_key': 'app_bot_0',
}

 response = requests.post('https://api.tapswap.ai/api/account/login', headers=headers, json=json_data, verify=False)
# access_token = response.json()['access_token']
 print(response.text)






'''

 headers1 = {
    'Host': 'api.tapswap.ai',
    # 'Content-Length': '31',
    'Sec-Ch-Ua': '"Chromium";v="124", "Android WebView";v="124", "Not-A.Brand";v="99"',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {access_token}',
    'X-Cv': '1',
    'Content-Type': 'application/json',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.6367.161 Mobile Safari/537.36',
    'X-App': 'tapswap_server',
    'Content-Id': '58604',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://app.tapswap.club',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://app.tapswap.club/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
    'Connection': 'close',
}

 json_data1 = {
    'taps': 500,
    'time': 1715564735340,
}

 response1 = requests.post('https://api.tapswap.ai/api/player/submit_taps', headers=headers1, json=json_data1, verify=False)
 print('77',response1.json()['player']['shares'])
 








'''

