import requests
import time
import json
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

au = [
    "query_id=AAHfxsFAAAAAAN_GwUArx2sx&user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1720355525&hash=1d10cef7921b12ff0a98aa0f5aeea469a0aeff18f0a2a0044977295ea0782bcb",
    "user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22cryptoooboy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=768107584393900953&chat_type=sender&auth_date=1720359391&hash=f50afbc057895fcfc3cc7e17e9d19e1cd8f225586ef73435c3a6cd1d1f468126",
    "user=%7B%22id%22%3A6737423619%2C%22first_name%22%3A%22Swa%22%2C%22last_name%22%3A%22Am%22%2C%22username%22%3A%22imSaraswathy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=2576169750466702223&chat_type=private&start_param=1086441183&auth_date=1720359622&hash=6255fb7008d3ce54a3b227d6f6c3f5fde7cc4bd58e3aecf293828e715641cd41",
    "user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=1967379381787425579&chat_type=private&start_param=1086441183&auth_date=1720359784&hash=67b432603858a9faf9c6ef39312eebfe2327f172b58a20d7f75fac52376c114f"
]

no = ["77", "31", "79", "99"]

def run_requests():
    start_time = time.time()
    while time.time() - start_time < 60:
        for a, n in zip(au, no):
            headers = {
                'Host': 'api.thevertus.app',
                'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
                'Accept': 'application/json, text/plain, */*',
                'Sec-Ch-Ua-Mobile': '?1',
                'Authorization': f'Bearer {a}',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
                'Sec-Ch-Ua-Platform': '"Android"',
                'Origin': 'https://thevertus.app',
                'X-Requested-With': 'org.telegram.messenger',
                'Sec-Fetch-Site': 'same-site',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Dest': 'empty',
                'Referer': 'https://thevertus.app/',
                'Accept-Language': 'en,en-US;q=0.9',
                'Priority': 'u=1, i',
            }

            json_data = {}

            response = requests.post('https://api.thevertus.app/game-service/collect', headers=headers, json=json_data, verify=False)
            response1 = requests.post('https://api.thevertus.app/users/claim-daily', headers=headers, json=json_data, verify=False)
            response2 = requests.post('https://api.thevertus.app/users/get-data', headers=headers, json=json_data, verify=False)
            print(n, (json.loads(response2.text)['user']['balance']) / (10**18))

        time.sleep(10)
try:
 while True:
    run_requests()
    print("killed")
except:
    print("RESTART")
