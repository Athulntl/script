import requests,time
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...4

list=["1086441183","7454287947","6796696313","6737423619","928159758"]
while True:
 for a in list:
  headers = {
    'Host': 'miner-webapp-fz9k.vercel.app',
    # 'Content-Length': '0',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://miner-webapp-fz9k.vercel.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://miner-webapp-fz9k.vercel.app/?id=7454287947',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

  params = {
    'id': a,
}

  response = requests.post('https://miner-webapp-fz9k.vercel.app/api/claim', params=params, headers=headers, verify=False)
  print(response.text)
 print("sleep for 1 hr")
 time.sleep(3600)
