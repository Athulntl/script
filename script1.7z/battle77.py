import asyncio
import websockets
import json
#count=0
async def send_message_with_battle_id():
    uri = "wss://api-clicker.pixelverse.xyz/socket.io/?EIO=4&transport=websocket"
    while True:
 #       count=+1
        try:
            async with websockets.connect(uri) as websocket:
                # Send the initial message to trigger the response containing battleId
                message = '40{"tg-id":1086441183,"secret":"91759e92473055184e6bac2b95e4b2d38612b32731f6d7d2a09be597aea14cf1","initData":"query_id=AAHfxsFAAAAAAN_GwUBmue5R&user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1718807052&hash=2d682a69212582b246d854530c16b7e8d7551b235fdc4183d9b1055bcde4bd90"}'
                await websocket.send(message)

                # Receive and parse the third response to extract battleId
                for _ in range(3):
                    response = await websocket.recv()
                try:
                    response_json = json.loads(response[response.index('['):])
                    battle_id = response_json[1]['battleId']
                    print("Extracted battleId:", battle_id)
                except (ValueError, KeyError):
                    print("Failed to extract battleId from response:", response)
                    return

                # Send messages infinitely with updated battleId
                while True:
                    updated_message = f'42["HIT",{{"battleId":"{battle_id}"}}]'
                    await websocket.send(updated_message)
                    #a = await websocket.recv()
                    #print("Sent updated message with battleId:", a)
                    await asyncio.sleep(0.09)  # Adjust the delay as needed

        except websockets.exceptions.ConnectionClosed:
            print("WebSocket connection closed. Reconnecting...")
  #          print("count ",count)
asyncio.run(send_message_with_battle_id())









