import requests,time

from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
while True:


 headers = {
    'Host': 'beer-tg-prod.onrender.com',
    # 'Content-Length': '12',
    'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Microsoft Edge";v="126", "Microsoft Edge WebView2";v="126"',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Sec-Ch-Ua-Mobile': '?0',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://beer-tg.web.app',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://beer-tg.web.app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Priority': 'u=1, i',
}

 params = {
    'tgInitData': 'query_id=AAHfxsFAAAAAAN_GwUC9xA9y&user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1718846544&hash=c25df2501f119e1dae601e78b4615c46f3eb88c029bfbb4d3825a00a0b9123bd',
}

 json_data = {
    'liters': 1.3,
}

 response = requests.post(
    'https://beer-tg-prod.onrender.com/game/batteryTaps',
    params=params,
    headers=headers,
    json=json_data,
    verify=False,)
 print("77",response.json()['balance']['lastBoonAmount'])
 time.sleep(2)
