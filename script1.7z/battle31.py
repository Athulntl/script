import asyncio
import websockets
import json
#c=0
async def send_message_with_battle_id():
    uri = "wss://api-clicker.pixelverse.xyz/socket.io/?EIO=4&transport=websocket"
    while True:
#        c+=1
        try:
            async with websockets.connect(uri) as websocket:
                # Send the initial message to trigger the response containing battleId
                message = '40{"tg-id":7454287947,"secret":"b3183358acf37b74ec4326addf423054befa2f399167197d287a7c88d4dfe465","initData":"query_id=AAFLaE88AwAAAEtoTzxF-VHi&user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22cryptoooboy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1718088885&hash=1a58bee04a516c04de2f11a9f6c46d0f5738c1990fec6b19e918beb909e65070"}'
                await websocket.send(message)

                # Receive and parse the third response to extract battleId
                for _ in range(3):
                    response = await websocket.recv()
                try:
                    response_json = json.loads(response[response.index('['):])
                    battle_id = response_json[1]['battleId']
                    print("Extracted battleId:", battle_id)
                except (ValueError, KeyError):
                    print("Failed to extract battleId from response:", response)
                    return

                # Send messages infinitely with updated battleId
                while True:
                    updated_message = f'42["HIT",{{"battleId":"{battle_id}"}}]'
                    await websocket.send(updated_message)
                    #a = await websocket.recv()
                    #print("Sent updated message with battleId:", a)
                    await asyncio.sleep(0.09)  # Adjust the delay 5as needed

        except websockets.exceptions.ConnectionClosed:
            print("WebSocket connection closed. Reconnecting...")
 #           print("count",c)
asyncio.run(send_message_with_battle_id())









