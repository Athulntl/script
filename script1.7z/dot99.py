import requests
import time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
count=0
# Your existing code here...
while True  :

 

 headers = {
    'Host': 'jjvnmoyncmcewnuykyid.supabase.co',
    # 'Content-Length': '15',
    'X-Client-Info': 'postgrest-js/1.9.2',
    'Sec-Ch-Ua': '"Chromium";v="124", "Android WebView";v="124", "Not-A.Brand";v="99"',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZWxlZ3JhbUlkIjo2Nzk2Njk2MzEzLCJpYXQiOjE3MTYwODUwODd9.0rJB6wOd5gp9qH-QHBeLo8oSlNC57SC8y0wkBuA2NKI',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.6367.161 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Content-Profile': 'public',
    'Apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Impqdm5tb3luY21jZXdudXlreWlkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDg3MDE5ODIsImV4cCI6MjAyNDI3Nzk4Mn0.oZh_ECA6fA2NlwoUamf1TqF45lrMC0uIdJXvVitDbZ8',
    'X-Telegram-User-Id': '1086441183',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://dot.dapplab.xyz',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://dot.dapplab.xyz/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = {
    'coins': 20000,
}

 response = requests.post(
    'https://jjvnmoyncmcewnuykyid.supabase.co/rest/v1/rpc/save_coins',
    headers=headers,
    json=json_data,
    verify=False,
)
 count+=1
 print('99 coin',response.text)
 
# Note: json_data will not be serialized by requests
# exactly as it was in the original request.
#data = '{"coins":20000}'
#response = requests.post(
#    'https://jjvnmoyncmcewnuykyid.supabase.co/rest/v1/rpc/save_coins',
#    headers=headers,
#    data=data,
#    verify=False,
#)
 #import requests

 headers1 = {
    'Host': 'jjvnmoyncmcewnuykyid.supabase.co',
    # 'Content-Length': '2',
    'X-Client-Info': 'postgrest-js/1.9.2',
    'Sec-Ch-Ua': '"Chromium";v="124", "Android WebView";v="124", "Not-A.Brand";v="99"',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZWxlZ3JhbUlkIjo2Nzk2Njk2MzEzLCJpYXQiOjE3MTYwODUwODd9.0rJB6wOd5gp9qH-QHBeLo8oSlNC57SC8y0wkBuA2NKI',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.6367.161 Mobile Safari/537.36',
    # Already added when you pass json=
    # 'Content-Type': 'application/json',
    'Content-Profile': 'public',
    'Apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Impqdm5tb3luY21jZXdudXlreWlkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDg3MDE5ODIsImV4cCI6MjAyNDI3Nzk4Mn0.oZh_ECA6fA2NlwoUamf1TqF45lrMC0uIdJXvVitDbZ8',
    'X-Telegram-User-Id': '1086441183',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://dot.dapplab.xyz',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://dot.dapplab.xyz/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data1 = {}
 if count==22:
    print("restoring")
    response1 = requests.post(
    'https://jjvnmoyncmcewnuykyid.supabase.co/rest/v1/rpc/restore_attempt',
    headers=headers1,
    json=json_data1,
    verify=False,
)
    count=0
    print('99 lvl',response1.text)
    if response1.json()['success']==False:
      time.sleep(2400)









