import requests
import time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
while True:


# Initial cookies and headers
 cookies = {
    '_ga': 'GA1.1.34506714.1719837480',
    'refresh_token': 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjUxNTczMDQ3In0.eyJ0ZWxlZ3JhbUlkIjoiNjczNzQyMzYxOSIsImlhdCI6MTcyMDE5Njc2OCwiZXhwIjoxNzIwMjgzMTY4LCJpc3MiOiJ0b25zdGF0aW9uIn0.tTsHq52yWHeomOdhVDMCa0BYdqmui6yM-fS24S8GVYlLCYUUSoBj0B9-8iUK3u3yMLPQ-tIk9we5xZgpXrJy4ZWbOyWegLRlw-pNiI5CCmNJNRrRPIYZYTtfw9xF7dzWOzCITyRjbcvwi5qWc0Jn5o9gkM6SA9DbzhQ4S-NcSdC2sEQN2qwm-ZhCJLctG0CZLYmsVIWzY-ESe-if_vIQpBZO6vFVh_jpRjMs0ih7qtRLZ1GwOs5tsMB4CD8HuBBdzuHuW5x9HlCFUJS2NP7bcM5-_3N-oFyiJEBTrWpz1QSWOeL_zjPpTRm862hmE6d6hCwdyHLYJRGy2EucXA3ALUSjPbTDFCeWUqCyrOKPLdMxNkjY4SvaupDOx4wCjhZpGRAj8XiCkTUKYnirARRBvSBGM9YdIJaGBUaswnTyDg1zS0aGuvXj6_Q2qSuxz1-kvzdrj8qBJS6N42NRoIKYKMvFXML4P0PA9QG7OPL1dby1gomcBL_azWc9UxMOpiHmtshvsNhQvBl4MQ0wa7hkp1MKSqhQkhy7-bBnegH-r0H7qtmcX1RcGhRHxVm0nzSVu0qv9TIxgq5dDfK2ykCm7msTgq0rTO1WVU5LFq8Yqb1jztHdjQHtZNaxkUFXEmTnARezDhfGeQsHDZmQxgoS6Jw2ZKjsG96AH8mQgwHCvw4',
    '_ga_TDW94HCJN6': 'GS1.1.1720196043.2.1.1720196791.32.1.1278515934',
}
 headers = {
    'Host': 'tonstation.app',
    # 'Content-Length': '270',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://tonstation.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tonstation.app/app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = {
    'user': {
        'id': 6796696313,
        'first_name': 'Akkku',
        'last_name': 'A',
        'username': 'adkdmdf',
        'language_code': 'en',
        'allows_write_to_pm': True,
    },
    'chat_instance': '-8253480645841900691',
    'chat_type': 'sender',
    'auth_date': '1720196795',
    'hash': 'f6d8fd8ef82435e2e325da4e863bfea31bc39858a196b51312b7b052434db61c',
}

 response = requests.post(
    'https://tonstation.app/userprofile/api/v1/users/auth',
    cookies=cookies,
    headers=headers,
    json=json_data,
    verify=False,
)
# print(response.text)
 a = response.json()['accessToken']
 r = response.json()['refreshToken']

# New cookies and headers with updated tokens
 cookies1 = {
    '_ga': 'GA1.1.34506714.1719837480',
    'accessToken': a,
    'refresh_token': r,
    '_ga_TDW94HCJN6': 'GS1.1.1720196043.2.1.1720196791.32.1.1278515934',
}
 headers1 = {
    'Host': 'tonstation.app',
    # 'Content-Length': '59',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {a}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://tonstation.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tonstation.app/app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data1 = {
    'userId': '6796696313',
    'taskId': '1',
}

 response1 = requests.post('https://tonstation.app/farming/api/v1/farming/start', cookies=cookies1, headers=headers1, json=json_data1, verify=False)
 print("99", response1.text)
 idd = response1.json()['data']['_id']
 print("99", idd)
 json_data2 = {
    'userId': '6796696313',
    'taskId': idd,
}
 print("99 started", idd)
 print("sleep for 8 hr")
 time.sleep(28810)

 while True:
    json_data = {
    'user': {
        'id': 6796696313,
        'first_name': 'Akkku',
        'last_name': 'A',
        'username': 'adkdmdf',
        'language_code': 'en',
        'allows_write_to_pm': True,
    },
    'chat_instance': '-8253480645841900691',
    'chat_type': 'sender',
    'auth_date': '1720196795',
    'hash': 'f6d8fd8ef82435e2e325da4e863bfea31bc39858a196b51312b7b052434db61c',
}
    response = requests.post(
    'https://tonstation.app/userprofile/api/v1/users/auth',
    cookies=cookies,
    headers=headers,
    json=json_data,
    verify=False,
)
    a = response.json()['accessToken']
    r = response.json()['refreshToken']

# New cookies and headers with updated tokens
    cookies2 = {
    '_ga': 'GA1.1.34506714.1719837480',
    'accessToken': a,
    'refresh_token': r,
    '_ga_TDW94HCJN6': 'GS1.1.1720196043.2.1.1720196791.32.1.1278515934',
}
    headers2 = {
    'Host': 'tonstation.app',
    # 'Content-Length': '59',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {a}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://tonstation.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tonstation.app/app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}
    
    response2 = requests.post('https://tonstation.app/farming/api/v1/farming/claim', cookies=cookies2, headers=headers2, json=json_data2, verify=False)
    if response2.status_code == 200:
        print("99 claimed", idd)
        print(response2.text)
        break
    else:
        print("Retrying...")
        time.sleep(5)
