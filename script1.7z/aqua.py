python aqua77.py & python aqua79.py & python aqua99.py &
