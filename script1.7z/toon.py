import requests,time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
tg=["user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-5801038583088941581&chat_type=sender&auth_date=1719393773&hash=5c0241522369b3a868e38759f9aee00c1afdc208b4da8f6e018dc782f769dcc1","user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22cryptoooboy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=6858687589796049570&chat_type=private&start_param=1086441183&auth_date=1719842066&hash=b94f245d29be08da3e0c0f43cfc7d0b5a91ce97b077939680410871f9496941d","user=%7B%22id%22%3A6737423619%2C%22first_name%22%3A%22Swa%22%2C%22last_name%22%3A%22Am%22%2C%22username%22%3A%22imSaraswathy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-2536369785604738146&chat_type=private&start_param=1086441183&auth_date=1719842382&hash=64e2cf6951689ca7801035a285f7fd975023305655570a5236ed511ad276fb56","user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=2559116035457179391&chat_type=private&start_param=1086441183&auth_date=1719842444&hash=7027539560ab0a06bbb4060469b9fb38d08b57f69b62b506ad4f35d3be2dd5f0"]
no=["77","31","79","99"]
while True:
  for t,n in zip(tg,no):
 
    headers = {
    'Host': 'b7zj6wf7falelnlhlz2r5y6r5e0zibdi.lambda-url.us-east-1.on.aws',
    # 'Content-Length': '384',
    'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Microsoft Edge";v="126", "Microsoft Edge WebView2";v="126"',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?0',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Origin': 'https://twa.photo-cdn.net',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://twa.photo-cdn.net/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Priority': 'u=1, i',
    'Connection': 'keep-alive',
}

    json_data = {
    'action': 'wallet.save.balance',
    'initData': t,
}
    json_data1 = {
    'action': 'safe.update.max_balance_level',
    'initData': t,
}
    json_data2 = {
    'action': 'wallet.update.speed_level',
    'initData': t,
}
 

    response = requests.post(
    'https://b7zj6wf7falelnlhlz2r5y6r5e0zibdi.lambda-url.us-east-1.on.aws/',
    headers=headers,
    json=json_data,
    verify=False,
)

    try:
     print(n,response.json()['user']['safe']['balance'])
     if(response.json()['user']['safe']['balance']==response.json()['user']['safe']['current_max_balance']):
      response = requests.post(
    'https://b7zj6wf7falelnlhlz2r5y6r5e0zibdi.lambda-url.us-east-1.on.aws/',
    headers=headers,
    json=json_data1,
    verify=False,
)  
      print("vault upgraded")
     if (response.json()['user']['safe']['balance']>response.json()['user']['wallet']['next_speed_price']) :
      response = requests.post(
    'https://b7zj6wf7falelnlhlz2r5y6r5e0zibdi.lambda-url.us-east-1.on.aws/',
    headers=headers,
    json=json_data2,
    verify= False,)
      print("speed upgraded")
    except:
     print("RESTART")












