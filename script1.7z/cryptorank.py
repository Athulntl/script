import requests,time

from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
tg=["eyJxdWVyeV9pZCI6IkFBSGZ4c0ZBQUFBQUFOX0d3VUJfeTNHRCIsInVzZXIiOnsiaWQiOjEwODY0NDExODMsImZpcnN0X25hbWUiOiJBdGh1bCIsImxhc3RfbmFtZSI6IkciLCJ1c2VybmFtZSI6IkFhYXRodWxsbCIsImxhbmd1YWdlX2NvZGUiOiJlbiIsImFsbG93c193cml0ZV90b19wbSI6dHJ1ZX0sImF1dGhfZGF0ZSI6IjE3MjA0OTIwMDMiLCJoYXNoIjoiZTgxODhkNTFhNzJkZTk4NjBiYjVhZjM5ZDAwNTlkMjUxYjFmNzY0MmI1ZWIwMWRmMTA3YWRlNjc2OTM0NjU3NyJ9","eyJ1c2VyIjp7ImlkIjo3NDU0Mjg3OTQ3LCJmaXJzdF9uYW1lIjoiY3J5cHRvYm95IiwibGFzdF9uYW1lIjoiIiwidXNlcm5hbWUiOiJjcnlwdG9vb2JveSIsImxhbmd1YWdlX2NvZGUiOiJlbiIsImFsbG93c193cml0ZV90b19wbSI6dHJ1ZX0sImNoYXRfaW5zdGFuY2UiOiItNDkyMjgwODAxNTcwNzM3NzExIiwiY2hhdF90eXBlIjoicHJpdmF0ZSIsInN0YXJ0X3BhcmFtIjoicmVmXzEwODY0NDExODNhIiwiYXV0aF9kYXRlIjoiMTcyMDQ5Mjg3MiIsImhhc2giOiIwNTVlMDI3MmY3OGQ5NWVkN2QzNjJhNDhhNmYyNjZjNWMyZGJiMTVhNDkyMzZlY2ZmMTQxYzVjNjNjOWExZTYzIn0=","eyJ1c2VyIjp7ImlkIjo2NzM3NDIzNjE5LCJmaXJzdF9uYW1lIjoiU3dhIiwibGFzdF9uYW1lIjoiQW0iLCJ1c2VybmFtZSI6ImltU2FyYXN3YXRoeSIsImxhbmd1YWdlX2NvZGUiOiJlbiIsImFsbG93c193cml0ZV90b19wbSI6dHJ1ZX0sImNoYXRfaW5zdGFuY2UiOiItMTc5ODEyMzczMzUzNDQ5MzIxOSIsImNoYXRfdHlwZSI6InByaXZhdGUiLCJzdGFydF9wYXJhbSI6InJlZl8xMDg2NDQxMTgzXyIsImF1dGhfZGF0ZSI6IjE3MjA0OTM0MDciLCJoYXNoIjoiN2MwNTVkOGZlOTAxNGNkM2ZkMDQzOWI4ZDAwZTA2NDA2MzdiZWE5ZjM3ZDdmZDgwZmE4NDM3Y2U5MTZhZWUxNyJ9","eyJ1c2VyIjp7ImlkIjo2Nzk2Njk2MzEzLCJmaXJzdF9uYW1lIjoiQWtra3UiLCJsYXN0X25hbWUiOiJBIiwidXNlcm5hbWUiOiJhZGtkbWRmIiwibGFuZ3VhZ2VfY29kZSI6ImVuIiwiYWxsb3dzX3dyaXRlX3RvX3BtIjp0cnVlfSwiY2hhdF9pbnN0YW5jZSI6Ii0xNDcxMjgzMTQ4NTEyMTI0NiIsImNoYXRfdHlwZSI6InByaXZhdGUiLCJzdGFydF9wYXJhbSI6InJlZl8xMDg2NDQxMTgzXyIsImF1dGhfZGF0ZSI6IjE3MjA0OTM2NjIiLCJoYXNoIjoiOGY5MTYzMmJkNmI1MDFlYjk3YTFiODFiYWJhYWU4YjY3NmZiMGRiMTk5NGViMTA3NTFhYWFhMjRmMTM2NjdjZCJ9","eyJxdWVyeV9pZCI6IkFBRU9tRkkzQUFBQUFBNllVamZkejRxOCIsInVzZXIiOnsiaWQiOjkyODE1OTc1OCwiZmlyc3RfbmFtZSI6IkFiaGluYXYiLCJsYXN0X25hbWUiOiJQIiwibGFuZ3VhZ2VfY29kZSI6ImVuIiwiYWxsb3dzX3dyaXRlX3RvX3BtIjp0cnVlfSwiYXV0aF9kYXRlIjoiMTcyMDY4NTg0NCIsImhhc2giOiI0NjA0NmNmNDBmYzA3NDJiMDcyNzNiMDE3ODVmNTk3NTQ3NjMyNzEyZjA0YTlhOWE5ZjNhNDJkNzI4MjI5MThiIn0="]
no=["77","31","79","99","ab"]
while True:

 for t,n in zip(tg,no):
 
 
  headers = {
    'Host': 'api.cryptorank.io',
    # 'Content-Length': '0',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': t,
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://tma.cryptorank.io',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tma.cryptorank.io/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}
  response4 = requests.post('https://api.cryptorank.io/v0/tma/account/end-farming', headers=headers, verify=False)
  print(n,response4.text)


  response = requests.post('https://api.cryptorank.io/v0/tma/account/start-farming', headers=headers, verify=False)
  print(n,response.text)
  response4 = requests.post('https://api.cryptorank.io/v0/tma/account/end-farming', headers=headers, verify=False)
  print(n,response4.text)
  response1 = requests.post('https://api.cryptorank.io/v0/tma/account/claim/task/e7dae272-7d17-4543-9a30-92f071439210', headers=headers, verify=False)
  response2 = requests.post('https://api.cryptorank.io/v0/tma/account/claim/task/dedafce3-4658-4eb4-bad5-f29b6cc500c9', headers=headers, verify=False)  
  response3 = requests.post('https://api.cryptorank.io//v0/tma/account/claim/task/db9876de-4b43-460e-b725-18e4ca6a0285', headers=headers, verify=False)
 print("sleep for 1 hr")
 time.sleep(3600)











