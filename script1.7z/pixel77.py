import requests,time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...

while True:

 headers = {
    'Host': 'api-clicker.pixelverse.xyz',
    # 'Content-Length': '0',
    'Secret': '91759e92473055184e6bac2b95e4b2d38612b32731f6d7d2a09be597aea14cf1',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.52 Mobile Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Username': 'Aaathulll',
    'Tg-Id': '1086441183',
    'Initdata': 'query_id=AAHfxsFAAAAAAN_GwUArVhwg&user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1717944970&hash=fd8fd653ea75d55996f62bd32302b3841d7369f3c1e46b0593b48b6601feebb6',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://sexyzbot.pxlvrs.io',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://sexyzbot.pxlvrs.io/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 response = requests.post('https://api-clicker.pixelverse.xyz/api/mining/claim', headers=headers, verify=False)
 response1 = requests.post('https://api-clicker.pixelverse.xyz/api/daily-rewards/claim', headers=headers, verify=False)
 print(response1.text)
 time.sleep(600)
 









