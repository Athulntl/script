import requests,time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
while True:

 headers = {
    'Host': 'beer-tg-prod.onrender.com',
    # 'Content-Length': '29',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://beer-tg.web.app',
    'X-Requested-With': 'com.iMe.android',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://beer-tg.web.app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 params = {
    'tgInitData': 'user=%7B%22id%22%3A6737423619%2C%22first_name%22%3A%22Swa%22%2C%22last_name%22%3A%22Am%22%2C%22username%22%3A%22imSaraswathy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-4721157000434138502&chat_type=private&start_param=_1086441183&auth_date=1718854804&hash=3506a472b7c2ec86c6adcac3250d000055722f65dfee1524d4eec7b3284a03a4',
}

 json_data = {
    'liters': 1.09,
}

 response = requests.post(
    'https://beer-tg-prod.onrender.com/game/batteryTaps',
    params=params,
    headers=headers,
    json=json_data,
    verify=False,
)

 print("79",response.json()['balance']['lastBoonAmount'])
 time.sleep(1)
