import requests

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
from datetime import datetime
while True:

 headers = {
    'Host': 'gamety-clicker-api.metafighter.com',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': 'Bearer  eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNzE2NTc1NTUxLCJpYXQiOjE3MTY1NTM5NTEsImp0aSI6ImFmOWU1MzZjYjRlNTQwNWQ4MjVjZGM2YjM1NzU0MDQwIiwidXNlcl9pZCI6MjQ5NjMwfQ.TQ9TrblUJ-rTM-0-zM_ekGvl5u1jFKbKUHLRw4gPWz0',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.52 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://gamety-clicker-build.s3.eu-central-1.amazonaws.com',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://gamety-clicker-build.s3.eu-central-1.amazonaws.com/',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 def get_current_utc_time():
    return datetime.utcnow().isoformat() + 'Z'

 def send_request():
    url = 'https://gamety-clicker-api.metafighter.com/api/v1/actions/click/'
    url1 = 'https://gamety-clicker-api.metafighter.com/api/v1/actions/defeat/'
    json_data = {
        'click_number': '1',
        'click_date': get_current_utc_time(),  # Get the current UTC time here
    }
    json_data1 = {
        'click_number': '0',
        'click_date': get_current_utc_time(),  # Get the current UTC time here
    }

    response = requests.post(url, headers=headers, json=json_data, verify=False)
    response1= requests.post(url1, headers=headers, json=json_data1, verify=False)
    return response

 def main():
        response = send_request()
        if response.status_code == 200:
            print('99', response.json())
        else:
            print('Failed to fetch data:', response.status_code, response.text)

 if __name__ == "__main__":
    main()







