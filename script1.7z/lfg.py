import requests,time
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
tg=["query_id=AAHfxsFAAAAAAN_GwUCv2FGh&user=%7B%22id%22%3A1086441183%2C%22first_name%22%3A%22Athul%22%2C%22last_name%22%3A%22G%22%2C%22username%22%3A%22Aaathulll%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1720489454&hash=18ca54d1e85749704e044b99b6f2e68d46dc958eb58f40814cf8a2728ddde2a9","user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22cryptoooboy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-6114943017626416970&chat_type=private&start_param=tbox_1926&auth_date=1720490235&hash=fe7e4acc2e6190bfaa81d7a36768ae627ae14e8c05323348a3516dab485ba50b","user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-7449505395398167055&chat_type=sender&auth_date=1720494181&hash=99f64b663041ce4f92135cf252bc1f1d840af4f7962053e298ad99f0825f511a"]
no=["77","31","99"]
while True:
 for t,n in zip(tg,no):


  headers = {
    'Host': 'api.lfgweb3.app',
    # 'Content-Length': '2',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    # Already added when you pass json=
    # 'Content-Type': 'application/json',
    'Miniapp-Initdata': t,
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://miniapp.lfgweb3.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://miniapp.lfgweb3.app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

  json_data = {}
  json_data2 = {
    'data': {},
} 
  
  json_data3 = {
    'data': {
        'purchase_booster_id': 3,
    },
}
  json_data4 = {
    'data': {
        'task': 'earned',
    },
}
  json_data5 = {
    'data': {
        'task': 'booster',
    },
} 


  response = requests.post('https://api.lfgweb3.app/lfg/v1/miniapp/task/claim', headers=headers, json=json_data5, verify=False)
  response = requests.post('https://api.lfgweb3.app/lfg/v1/miniapp/task/claim', headers=headers, json=json_data4, verify=False)
  response = requests.post('https://api.lfgweb3.app/lfg/v1/miniapp/mine/purchase', headers=headers, json=json_data3, verify=False)
  response = requests.post('https://api.lfgweb3.app/lfg/v1/miniapp/task/sign', headers=headers, json=json_data, verify=False)
  print(n,"claimed")
  response1 = requests.post('https://api.lfgweb3.app/lfg/v1/miniapp/mine/start', headers=headers, json=json_data, verify=False)
  print(n,response.text)
  response2 = requests.post('https://api.lfgweb3.app/lfg/v1/miniapp/mine/tap', headers=headers, json=json_data2, verify=False)
  print(n,response2.text)
 print("sleep for 10 min")
 time.sleep(600)