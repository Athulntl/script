import requests
import time
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)



while True:
# time.sleep(2)

 headers = {
    'Host': 'db4.onchaincoin.io',
    # 'Content-Length': '295',
    'Sec-Ch-Ua': '"Chromium";v="124", "Android WebView";v="124", "Not-A.Brand";v="99"',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.6367.161 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://db4.onchaincoin.io',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://db4.onchaincoin.io/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = {
    'hash': 'query_id=AAH5Wh0VAwAAAPlaHRX5zybX&user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1715926850&hash=4ec2fc4d30111cf9c950824a479d605ec99b77d80a550e6b3595f071775eda18',
}

 response = requests.post('https://db4.onchaincoin.io/api/validate', headers=headers, json=json_data, verify=False)
 token = response.json()['token']
 #print(token)


#import requests

 cookies = {
    '_ga': 'GA1.1.982432134.1715913823',
    '_ga_Z6Z992LEQC': 'GS1.1.1715913823.1.1.1715916975.0.0.0',
}

 headers1 = {
    'Host': 'db4.onchaincoin.io',
    # 'Content-Length': '13',
    'Sec-Ch-Ua': '"Chromium";v="124", "Android WebView";v="124", "Not-A.Brand";v="99"',
    'Accept': '5application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {token}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.6367.161 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://db4.onchaincoin.io',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://db4.onchaincoin.io/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
    # 'Cookie': '_ga=GA1.1.982432134.1715913823; _ga_Z6Z992LEQC=GS1.1.1715913823.1.1.1715916975.0.0.0',
}

 json_data1 = {
    'clicks': 1,
}
 response1 = requests.post(
    'https://db4.onchaincoin.io/api/klick/myself/click',
    cookies=cookies,
    headers=headers1,
    json=json_data1,
    verify=False,
)
 print('99',response1.text)
