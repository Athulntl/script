import requests,time
import requests,time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
while True:

 headers = {
    'Host': 'beer-tg-prod.onrender.com',
    # 'Content-Length': '29',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://beer-tg.web.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://beer-tg.web.app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 params = {
    'tgInitData': 'user=%7B%22id%22%3A6796696313%2C%22first_name%22%3A%22Akkku%22%2C%22last_name%22%3A%22A%22%2C%22username%22%3A%22adkdmdf%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-7876909334858279288&chat_type=private&start_param=_1086441183&auth_date=1718855374&hash=30f8f0c760e30aaff1ef0461e4f17c0d2e20347f7506703fa7b302c39b31aa6d',
}

 json_data = {
    'liters': 1.2,
}

 response = requests.post(
    'https://beer-tg-prod.onrender.com/game/batteryTaps',
    params=params,
    headers=headers,
    json=json_data,
    verify=False,
)

 print("99",response.json()['balance']['lastBoonAmount'])
 time.sleep(1)

