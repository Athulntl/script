python blum77.py & python blum79.py & python blum99.py &
