import requests
import time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...
while True:


# Initial cookies and headers
 cookies = {
    '_ga': 'GA1.1.34506714.1719837480',
    'accessToken': 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjUxNTczMDQ3In0.eyJfaWQiOiI2Njg2YzFiMWI5YjJiNDAwMTIyM2MyMGQiLCJ0ZWxlZ3JhbUlkIjoiNzQ1NDI4Nzk0NyIsInVzZXJOYW1lIjoiY3J5cHRvb29ib3kiLCJhZGRyZXNzIjoiMHgyOWRmOTk5Njg2MDQ5Zjc5YzM4MTYyNjIyZWFlMGI2NjRlMjliNjBiIiwiY3JlYXRlZEF0IjoiMjAyNC0wNy0wNFQxNTozNzoyMS45MjlaIiwidXBkYXRlZEF0IjoiMjAyNC0wNy0wNFQxNTozNzoyMS45MjlaIiwiX192IjowLCJpYXQiOjE3MjAxOTE0MzYsImV4cCI6MTcyMDE5NTAzNiwiaXNzIjoidG9uc3RhdGlvbiJ9.q-MiDf_uW3h8DhPDrq0S2nUshbJOfjpJwTChSvxTpgkpzJWPSks8R2An_M6ivyBj3XMf5oa5PPuGsAeORfU0B4uCfRB3F3Ghv59ePoJyApZ6ZKSFV7iT4FNWos3myUalSzXdY07UE6etPrm3r0PJCqa2gZnPbpY5etvbMhgQmi4pX5ObMXM28NwabqXmAIIDO4QuQ2X4nAq7MrEREITRzy2GVm_sz8BdOAC0HZTZgzOCBM2pW9ugjZaav-9iquQNgpdiOhCqdMjlaiksZmzeI-m4VKphtQQnbEWBhBwELZzeewBHWTXJRfvQjfPIe7K7UncqNqFT0sHdjVRISzmDllnLvEmhnr3VOpZBKJ8jtmk0ZezUyP65S5tQ7fFUPmDjfp3CB5jI7jglpg8AL8cGsXq9mvI_Z_eeGRpAcHk5LLpWJYr-dwIUm3koi0u1col2nq4zXy3aR3rdHTKcMq4G2ad0_6hIeASfbQ-NkIbKbcblwh6TmsNYZMXeJNaLF_I2bjPg76NFqP7Q72-56_L-Wna3rlw6slKKsnD8fwIA-ynuBhDAnKEJPKxAyibZ2OT_o-O-SQNALz6efTaYLKozMRKrst3BE_kRt_5TlJJydsUKZyYBk14SQmVc9iFXfOvagXRBlbCML8nrnIaxhbnIuINwIOdo8jPfkQjrVYd7Aes',
    'refresh_token': 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjUxNTczMDQ3In0.eyJ0ZWxlZ3JhbUlkIjoiNzQ1NDI4Nzk0NyIsImlhdCI6MTcyMDE5MTQzNiwiZXhwIjoxNzIwMjc3ODM2LCJpc3MiOiJ0b25zdGF0aW9uIn0.miAWQklpGzV09wz3F-muj7BbrkKgG9jWA5ybugfXXEZ4lKHjKUi2w45M_FF0j6OWNhp1-SvRm3ECs74haq-IMN6gfcpK2qpck3V5BXLmmu2wJH3RcfspVyi0SbdqwjM-PVR-CjA560BCXsmNHrRjst_enMKM3xegcQJ4PT8DgWZqYl3OLdLfaJH5GBDtoJN62NLsqI5Jp0FH4nol7zftWbF8PMFbQ6GyQ5URcp9eLNjVLBl_sUNfzUKa7pw7IDte3VR88ShF0r4FCjaiumMkvUKg8g4E2xjK0taBWtAWwlSBsF0qcGz0hW1rXhJpW2jcz8QeoarWxwvJA97_Ovtc1BZi0OEhlkC6E-_emGMcB2qMzE8FKFKf39MVQac97JUG7Eg-zi7oE8LNHT49yZBSmVeZ3C0grr1YoT8Tu7R1Hz4JbgRiGnmOBcn4X2rYTW3D6c_tIVKLCNqFQWrkbHsxMNHR9GjQcXq3gMAYyREiHnGJgZogTJZYhg1V4npsXg22kvHF_z2P5sRyNLKxS1Gh50UbSVZzDuSPMssr5hjW17O7tiNV5KPIly0A0pEzgBis6WC8jpc31P9XpP4GUMwdAjCCEwTgXhMv_GykKDMAvY8ZfDNgyCfBPybSp1GXOtoVydVLeKtHKeflrbI3KRMN7ORu8FF6izrMCvWhU3uT_Jc',
    '_ga_TDW94HCJN6': 'GS1.1.1720194646.4.0.1720194646.60.0.113911460',
}

 headers = {
    'Host': 'tonstation.app',
    # 'Content-Length': '270',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://tonstation.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tonstation.app/app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = {
    'query_id': 'AAHfxsFAAAAAAN_GwUBnS-o5',
    'user': {
        'id': 1086441183,
        'first_name': 'Athul',
        'last_name': 'G',
        'username': 'Aaathulll',
        'language_code': 'en',
        'allows_write_to_pm': True,
    },
    'auth_date': '1720194649',
    'hash': '76bbb5dda0230a1113029a604904a20d279d553a87eafe64f95dd50e9f1aa0cc',
}

 response = requests.post(
    'https://tonstation.app/userprofile/api/v1/users/auth',
    cookies=cookies,
    headers=headers,
    json=json_data,
    verify=False,
)
# print(response.text)
 a = response.json()['accessToken']
 r = response.json()['refreshToken']

# New cookies and headers with updated tokens
 cookies1 = {
    '_ga': 'GA1.1.34506714.1719837480',
    'accessToken': a,
    'refresh_token': r,
    '_ga_TDW94HCJN6': 'GS1.1.1720194646.4.0.1720194646.60.0.113911460',
}
 headers1 = {
    'Host': 'tonstation.app',
    # 'Content-Length': '59',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {a}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://tonstation.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tonstation.app/app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data1 = {
    'userId': '1086441183',
    'taskId': '1',
}

 response1 = requests.post('https://tonstation.app/farming/api/v1/farming/start', cookies=cookies1, headers=headers1, json=json_data1, verify=False)
 print("77", response1.text)
 idd = response1.json()['data']['_id']
 print("77", idd)
 json_data2 = {
    'userId': '1086441183',
    'taskId': idd,
}
 print("77 started", idd)
 print("sleep for 8 hr")
 time.sleep(28810)

 while True:
    json_data = {
    'query_id': 'AAHfxsFAAAAAAN_GwUBnS-o5',
    'user': {
        'id': 1086441183,
        'first_name': 'Athul',
        'last_name': 'G',
        'username': 'Aaathulll',
        'language_code': 'en',
        'allows_write_to_pm': True,
    },
    'auth_date': '1720194649',
    'hash': '76bbb5dda0230a1113029a604904a20d279d553a87eafe64f95dd50e9f1aa0cc',
}
    response = requests.post(
    'https://tonstation.app/userprofile/api/v1/users/auth',
    cookies=cookies,
    headers=headers,
    json=json_data,
    verify=False,
)
    print(response.text)
    a = response.json()['accessToken']
    r = response.json()['refreshToken']

# New cookies and headers with updated tokens
    cookies2 = {
    '_ga': 'GA1.1.34506714.1719837480',
    'accessToken': a,
    'refresh_token': r,
    '_ga_TDW94HCJN6': 'GS1.1.1720194646.4.0.1720194646.60.0.113911460',
}
    headers2 = {
    'Host': 'tonstation.app',
    # 'Content-Length': '59',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {a}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://tonstation.app',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tonstation.app/app/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}
    
    response2 = requests.post('https://tonstation.app/farming/api/v1/farming/claim', cookies=cookies2, headers=headers2, json=json_data2, verify=False)
    if response2.status_code == 200:
        print("77 claimed", idd)
        print(response2.text)
        break
    else:
        print("Retrying...")
        time.sleep(5)
