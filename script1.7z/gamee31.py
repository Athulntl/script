import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
import time
while True:

 headers = {
    'Host': 'api.service.gameeapp.com',
    # 'Content-Length': '490',
    'Client-Language': 'en',
    'Sec-Ch-Ua': '"Chromium";v="124", "Android WebView";v="124", "Not-A.Brand";v="99"',
    'X-Install-Uuid': 'b1946ca5-f90c-43f1-baad-538250c62a2e',
    'Content-Type': 'text/plain;charset=UTF-8',
    'Sec-Ch-Ua-Mobile': '?1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.6367.161 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://prizes.gamee.com',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://prizes.gamee.com/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 data = '{"jsonrpc":"2.0","id":"user.authentication.loginUsingTelegram","method":"user.authentication.loginUsingTelegram","params":{"initData":"user=%7B%22id%22%3A7454287947%2C%22first_name%22%3A%22cryptoboy%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22cryptoooboy%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-3184277224143969609&chat_type=sender&auth_date=1717527132&hash=61d407cb9c845d5ae6d9a77c2c1fe5c13542ea6da0da4e6d42c56c7baa156cee"}}'

 response = requests.post('https://api.service.gameeapp.com/', headers=headers, data=data, verify=False)
 token=response.json()['result']['tokens']['refresh']

 import requests

 headers1 = {
    'Host': 'api.service.gameeapp.com',
    # 'Content-Length': '114',
    'Client-Language': 'en',
    'Sec-Ch-Ua': '"Chromium";v="124", "Android WebView";v="124", "Not-A.Brand";v="99"',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': f'Bearer {token}',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.6367.161 Mobile Safari/537.36',
    'Content-Type': 'text/plain;charset=UTF-8',
    'X-Install-Uuid': 'fd9c555a-177f-4532-8205-0f5e54a05118',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Accept': '*/*',
    'Origin': 'https://prizes.gamee.com',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://prizes.gamee.com/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 data1 = '{"jsonrpc":"2.0","id":"miningEvent.get","method":"miningEvent.get","params":{"miningEventId":26}}'
 data2= '{"jsonrpc":"2.0","id":"miningEvent.startSession","method":"miningEvent.startSession","params":{"miningEventId":26}}'

 response2 = requests.post('https://api.service.gameeapp.com/', headers=headers1, data=data2, verify=False)

 response1 = requests.post('https://api.service.gameeapp.com/', headers=headers1, data=data1, verify=False)
 print(response1.text)
 time.sleep(3600)









 


