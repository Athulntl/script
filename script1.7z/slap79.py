import requests
import time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...

# Get the current timestamp in milliseconds
current_timestamp = int(time.time() * 1000)
while True:

 headers = {
    'Host': 'api.clicker.wormfare.com',
    'Sec-Ch-Ua': '"Android WebView";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjY3Mzc0MjM2MTksImlhdCI6MTcyMDc0OTcwMSwiZXhwIjoxODQ2ODkzNzAxfQ.pE106rras-HuZKaU1kZeQHrfyba1L0wLOo5WuaSLNgI',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.186 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': 'application/json, text/plain, */*',
    'X-Api-Key': '9m60AhO1I9JmrYIsWxMnThXbF3nDW4GHFA1rde5PKzJmRA9Dv6LZ2YXSM6vvwigC',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://clicker.wormfare.com',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-FetchMode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://clicker.wormfare.com/',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}

 json_data = {
    'startTimestamp': current_timestamp,
    'amount': 1500,
    'isTurbo': False,
}

 response = requests.post(
    'https://api.clicker.wormfare.com/game/save-clicks',
    headers=headers,
    json=json_data,
    verify=False,
)
 try:
   print("79",response.json()['score'])
 except:
   print("79",response.text)
   
