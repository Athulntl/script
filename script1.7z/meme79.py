import requests
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Disable insecure request warning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Your existing code here...

import time
while True:
 time.sleep(10)
 headers = {
    'Host': 'api-gw-tg.memefi.club',
    # 'Content-Length': '1035',
    'Sec-Ch-Ua': '"Chromium";v="124", "Android WebView";v="124", "Not-A.Brand";v="99"',
    'Accept': '*/*',
    'Content-Type': 'application/json',
    'Sec-Ch-Ua-Mobile': '?1',
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7Il9pZCI6IjY2NDE3MzVlOGYzNjY1OTY4ZWNhNjYwNCIsInVzZXJuYW1lIjoibm90X3Byb3ZpZGVkIn0sInNlc3Npb25JZCI6IjY2NDE3MzY5YWE3ODFlNGJkYWMyOTRkMSIsInN1YiI6IjY2NDE3MzVlOGYzNjY1OTY4ZWNhNjYwNCIsImlhdCI6MTcxNTU2NTQxNywiZXhwIjoxNzE2MTcwMjE3fQ.QFXJPtnn0C_-ICMwjqVh32hdC5giUSUdbJdQnPCAgXY',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; ASUS_I005DA Build/PI; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.6367.161 Mobile Safari/537.36',
    'Sec-Ch-Ua-Platform': '"Android"',
    'Origin': 'https://tg-app.memefi.club',
    'X-Requested-With': 'org.telegram.messenger',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://tg-app.memefi.club/',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en,en-US;q=0.9',
    'Priority': 'u=1, i',
}
 proxies = {
    'http': 'http://127.0.0.1:8080',
    'https': 'http://127.0.0.1:8080',
}

 json_data = {
    'operationName': 'MutationGameProcessTapsBatch',
    'variables': {
        'payload': {
            'nonce': '4c8c727c6ed20b910d89e6c4342da9a08f478425bf7a9249f4e21bfa2ce86a9b',
            'tapsCount': 300,
        },
    },
    'query': 'mutation MutationGameProcessTapsBatch($payload: TelegramGameTapsBatchInput!) {\n  telegramGameProcessTapsBatch(payload: $payload) {\n    ...FragmentBossFightConfig\n    __typename\n  }\n}\n\nfragment FragmentBossFightConfig on TelegramGameConfigOutput {\n  _id\n  coinsAmount\n  currentEnergy\n  maxEnergy\n  weaponLevel\n  energyLimitLevel\n  energyRechargeLevel\n  tapBotLevel\n  currentBoss {\n    _id\n    level\n    currentHealth\n    maxHealth\n    __typename\n  }\n  freeBoosts {\n    _id\n    currentTurboAmount\n    maxTurboAmount\n    turboLastActivatedAt\n    turboAmountLastRechargeDate\n    currentRefillEnergyAmount\n    maxRefillEnergyAmount\n    refillEnergyLastActivatedAt\n    refillEnergyAmountLastRechargeDate\n    __typename\n  }\n  bonusLeaderDamageEndAt\n  bonusLeaderDamageStartAt\n  bonusLeaderDamageMultiplier\n  nonce\n  __typename\n}',
}

 response = requests.post('https://api-gw-tg.memefi.club/graphql', headers=headers, json=json_data, verify=False,proxies=proxies)
 print('Total Coin')
 print(response.json()['data']['telegramGameProcessTapsBatch']['coinsAmount'])
 print ('Health')
 print(response.json()['data']['telegramGameProcessTapsBatch']['currentBoss']['currentHealth'])
